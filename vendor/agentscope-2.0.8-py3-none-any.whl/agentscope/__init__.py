# -*- coding: utf-8 -*-
"""The agentscope package."""
import warnings

from ._logging import (
    logger,
    setup_logger,
)
from ._utils._common import set_id_factory, set_timestamp_factory
from ._version import __version__

# Raise each warning only once
warnings.filterwarnings("once", category=DeprecationWarning)


__all__ = [
    "logger",
    "setup_logger",
    "set_id_factory",
    "set_timestamp_factory",
    "__version__",
]
