# -*- coding: utf-8 -*-
"""Storage model for business refund proposals."""
from datetime import datetime
from enum import Enum

from pydantic import Field

from ._base import _RecordBase
from ...._utils._common import _generate_id


class RefundProposalStatus(str, Enum):
    """Ordered business states for a refund proposal."""

    PENDING_CUSTOMER_CONFIRMATION = "PENDING_CUSTOMER_CONFIRMATION"
    PENDING_STAFF_APPROVAL = "PENDING_STAFF_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"
    EXECUTING = "EXECUTING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"
    READY_TO_RETRY = "READY_TO_RETRY"


class RefundExecutionAttemptStatus(str, Enum):
    """State of one external refund execution attempt."""

    EXECUTING = "EXECUTING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"
    NOT_ACCEPTED = "NOT_ACCEPTED"


class RefundProposalRecord(_RecordBase):
    """A server-owned, not-yet-executed refund proposal.

    The storage ``id`` is the business ``operation_id``.  Scope and all
    refund parameters are immutable so later approval cannot silently change
    what was proposed.
    """

    id: str = Field(
        default_factory=_generate_id,
        frozen=True,
    )

    tenant_id: str = Field(min_length=1, frozen=True)
    customer_id: str = Field(min_length=1, frozen=True)
    order_id: str = Field(min_length=1, frozen=True)
    ticket_id: str = Field(min_length=1, frozen=True)
    requester_user_id: str = Field(min_length=1, frozen=True)
    session_id: str = Field(min_length=1, frozen=True)

    amount_minor: int = Field(gt=0, frozen=True)
    currency: str = Field(min_length=1, frozen=True)
    policy_id: str = Field(min_length=1, frozen=True)
    policy_version: str = Field(min_length=1, frozen=True)
    policy_effective_at: datetime = Field(frozen=True)
    evidence_ids: tuple[str, ...] = Field(frozen=True)
    requires_staff_approval: bool = Field(frozen=True)
    request_fingerprint: str = Field(min_length=1, frozen=True)
    expires_at: datetime = Field(frozen=True)
    staff_approved_by_user_id: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    staff_approved_at: datetime | None = Field(
        default=None,
        frozen=True,
    )
    execution_attempts: int = Field(default=0, ge=0, frozen=True)
    latest_execution_attempt_id: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    status_query_attempt_count: int = Field(default=0, ge=0, frozen=True)
    last_attempt_at: datetime | None = Field(default=None, frozen=True)
    last_error_type: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    reconciliation_required: bool = Field(default=False, frozen=True)
    reconciled_by_user_id: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    reconciled_at: datetime | None = Field(default=None, frozen=True)
    reconciliation_evidence_id: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    reconciliation_reason: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    # Automatic recovery only observes the provider; it never submits a new
    # refund.  The lease fields protect that observation from concurrent or
    # late workers across processes.
    next_recovery_at: datetime | None = Field(default=None, frozen=True)
    recovery_lease_owner: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    recovery_lease_token: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    recovery_lease_expires_at: datetime | None = Field(
        default=None,
        frozen=True,
    )
    external_request_id: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    execution_started_at: datetime | None = Field(
        default=None,
        frozen=True,
    )
    execution_finished_at: datetime | None = Field(
        default=None,
        frozen=True,
    )
    last_error: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    # ``state_version`` is the refund-status transition version published in
    # business events. ``record_version`` tracks every persisted mutation and
    # is suitable for backends that use explicit optimistic concurrency.
    state_version: int = Field(default=1, ge=1, frozen=True)
    record_version: int = Field(default=1, ge=1, frozen=True)
    status: RefundProposalStatus = (
        RefundProposalStatus.PENDING_CUSTOMER_CONFIRMATION
    )

    @property
    def operation_id(self) -> str:
        """Return the server-generated business operation identifier."""
        return self.id


class RefundExecutionAttemptRecord(_RecordBase):
    """Append-only audit state for one attempt under one refund operation.

    ``operation_id`` and ``provider_idempotency_key`` stay stable across
    retries.  ``id`` is the attempt-specific identifier, while
    ``external_request_id`` is the provider request identifier observed for
    this attempt and may be absent when the result is unknown.
    """

    id: str = Field(
        default_factory=_generate_id,
        frozen=True,
    )
    tenant_id: str = Field(min_length=1, frozen=True)
    customer_id: str = Field(min_length=1, frozen=True)
    operation_id: str = Field(min_length=1, frozen=True)
    attempt_number: int = Field(gt=0, frozen=True)
    provider_idempotency_key: str = Field(min_length=1, frozen=True)
    external_request_id: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )
    status: RefundExecutionAttemptStatus = (
        RefundExecutionAttemptStatus.EXECUTING
    )
    started_at: datetime = Field(frozen=True)
    finished_at: datetime | None = Field(default=None, frozen=True)
    last_error: str | None = Field(default=None, min_length=1, frozen=True)

    @property
    def execution_attempt_id(self) -> str:
        """Return the attempt-specific identifier."""
        return self.id
