# -*- coding: utf-8 -*-
"""Storage model for business after-sales tickets."""
from enum import Enum

from pydantic import Field

from ._base import _RecordBase
from ...._utils._common import _generate_id


class TicketStatus(str, Enum):
    """Statuses supported by the first ticket increment."""

    OPEN = "OPEN"


class TicketRecord(_RecordBase):
    """A server-owned after-sales ticket.

    ``id`` is the storage convention for the server-generated ticket id;
    ``ticket_id`` is provided as a read-only business alias. Scope fields
    are frozen so later updates cannot silently move a ticket across a
    tenant or customer boundary.
    """

    id: str = Field(
        default_factory=_generate_id,
        frozen=True,
        description="Server-generated ticket identifier.",
    )

    tenant_id: str = Field(min_length=1, frozen=True)
    customer_id: str = Field(min_length=1, frozen=True)
    requester_user_id: str = Field(min_length=1, frozen=True)
    order_id: str = Field(min_length=1, frozen=True)
    session_id: str = Field(min_length=1, frozen=True)

    title: str = Field(min_length=1)
    description: str = Field(min_length=1)
    category: str = Field(default="物流", min_length=1)
    priority: str = Field(default="NORMAL", min_length=1)
    status: TicketStatus = TicketStatus.OPEN

    @property
    def ticket_id(self) -> str:
        """Business-facing alias for the storage record id."""
        return self.id
