# -*- coding: utf-8 -*-
"""Storage model for durable business events waiting for publication."""
from datetime import datetime

from pydantic import Field

from ._base import _RecordBase
from ...._utils._common import _generate_id


class OutboxEventRecord(_RecordBase):
    """One immutable business event plus its publication bookkeeping."""

    id: str = Field(
        default_factory=_generate_id,
        frozen=True,
    )

    event_type: str = Field(min_length=1, frozen=True)
    tenant_id: str = Field(min_length=1, frozen=True)
    customer_id: str = Field(min_length=1, frozen=True)
    session_id: str = Field(min_length=1, frozen=True)
    operation_id: str = Field(min_length=1, frozen=True)
    status: str = Field(min_length=1, frozen=True)
    state_version: int = Field(ge=1, frozen=True)
    occurred_at: datetime = Field(frozen=True)
    published_at: datetime | None = Field(default=None, frozen=True)
    publish_attempts: int = Field(default=0, ge=0, frozen=True)
    last_error: str | None = Field(
        default=None,
        min_length=1,
        frozen=True,
    )

    @property
    def event_id(self) -> str:
        """Return the stable id used for publication deduplication."""
        return self.id
