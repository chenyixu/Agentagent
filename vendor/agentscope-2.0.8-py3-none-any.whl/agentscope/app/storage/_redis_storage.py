# -*- coding: utf-8 -*-
# pylint: disable=too-many-public-methods
"""The Redis storage implementation."""

import warnings
import json
from datetime import datetime, timedelta, timezone
from typing import Any, TYPE_CHECKING, Self

from pydantic import BaseModel

from ._base import StorageBase
from ._model._session import _origin_kwargs
from ._model import (
    AgentRecord,
    ChannelRecord,
    CredentialRecord,
    KnowledgeBaseRecord,
    KnowledgeDocumentRecord,
    KnowledgeDocumentStatus,
    MCPRecord,
    ScheduleRecord,
    SessionRecord,
    SessionConfig,
    ChannelOrigin,
    ScheduleOrigin,
    SessionOrigin,
    SkillRecord,
    TeamRecord,
    RefundExecutionAttemptRecord,
    RefundExecutionAttemptStatus,
    RefundProposalRecord,
    RefundProposalStatus,
    OutboxEventRecord,
    TicketRecord,
    TicketStatus,
)
from ._utils import _dump_with_secrets
from ...credential import CredentialBase
from ...message import Msg
from ...state import AgentState

if TYPE_CHECKING:
    from redis.asyncio import ConnectionPool, Redis
else:
    ConnectionPool = Any
    Redis = Any


def _watch_error() -> type[BaseException]:
    """Return the ``WatchError`` class from ``redis.exceptions``.

    Lazy-imported so ``redis`` stays an optional dependency at module
    load time — same trick the storage class uses in ``__aenter__``.
    """
    from redis.exceptions import WatchError

    return WatchError


class RedisStorage(StorageBase):
    """The Redis storage implementation."""

    class KeyConfig(BaseModel):
        """Key templates for all Redis keys used by :class:`RedisStorage`.

        Nested on :class:`RedisStorage` because customising key prefixes
        is meaningful only for this backend; users tweak them via
        ``RedisStorage(key_config=RedisStorage.KeyConfig(...))``.
        """

        # Record keys
        credential: str = (
            "agentscope:user:{user_id}:credential:{credential_id}"
        )
        agent: str = "agentscope:user:{user_id}:agent:{agent_id}"
        session: str = "agentscope:user:{user_id}:session:{session_id}"
        mcp: str = "agentscope:user:{user_id}:mcp:{mcp_id}"
        skill: str = "agentscope:user:{user_id}:skill:{skill_id}"

        # Index keys (Redis Sets — store all IDs for a given scope)
        credential_index: str = "agentscope:user:{user_id}:credentials"
        agent_index: str = "agentscope:user:{user_id}:agents"
        mcp_index: str = "agentscope:user:{user_id}:mcps"
        skill_index: str = "agentscope:user:{user_id}:skills"

        # Name indexes (Redis Hash — name → record id). Each doubles as
        # the per-user uniqueness constraint and as the lookup for the
        # workspace relation, which joins on name rather than record id.
        mcp_name_index: str = "agentscope:user:{user_id}:mcp_names"
        skill_name_index: str = "agentscope:user:{user_id}:skill_names"
        session_index: str = (
            "agentscope:user:{user_id}:agent:{agent_id}:sessions"
        )

        # Lookup key: maps (user_id, agent_id) → session_id
        session_lookup: str = (
            "agentscope:user:{user_id}:agent:{agent_id}:session"
        )

        # Message list key (Redis List — ordered message history per session)
        messages: str = (
            "agentscope:user:{user_id}:session:{session_id}:messages"
        )

        schedule: str = "agentscope:user:{user_id}:schedule:{schedule_id}"
        schedule_index: str = "agentscope:user:{user_id}:schedules"
        schedule_global_index: str = "agentscope:schedules"
        schedule_session_index: str = (
            "agentscope:user:{user_id}:schedule:{schedule_id}:sessions"
        )

        # channel_id is a globally unique UUID, so the record lives at a
        # single global key. Indexes: per-user (management list),
        # all-channels (reconcile enumeration), bot-id (uniqueness /
        # dedup).
        channel: str = "agentscope:channel_record:{channel_id}"
        channel_index: str = "agentscope:user:{user_id}:channels"
        channel_all_index: str = "agentscope:channels"
        channel_botid_index: str = "agentscope:channel_botid:{platform_bot_id}"
        channel_session_index: str = (
            "agentscope:user:{user_id}:channel:{channel_id}:sessions"
        )

        team: str = "agentscope:user:{user_id}:team:{team_id}"
        team_index: str = "agentscope:user:{user_id}:teams"

        # Business ticket keys are scoped by both tenant and customer. A
        # ticket id alone is never used to address a business record.
        ticket: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":ticket:{ticket_id}"
        )
        ticket_index: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}:tickets"
        )
        ticket_open: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":ticket:open:{order_id}"
        )
        ticket_idempotency: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":user:{requester_user_id}:operation:{operation}"
            ":idempotency:{idempotency_key}"
        )
        refund_proposal: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":refund-proposal:{operation_id}"
        )
        refund_proposal_index: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":refund-proposals"
        )
        refund_proposal_session_index: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":session:{session_id}:refund-proposals"
        )
        refund_proposal_active: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":refund-proposal:active:{order_id}"
        )
        refund_proposal_idempotency: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":user:{requester_user_id}:operation:create-refund-proposal"
            ":idempotency:{idempotency_key}"
        )
        refund_execution_attempt: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":refund-proposal:{operation_id}:attempt:{execution_attempt_id}"
        )
        refund_execution_attempt_index: str = (
            "agentscope:tenant:{tenant_id}:customer:{customer_id}"
            ":refund-proposal:{operation_id}:attempts"
        )
        # A global due index is intentionally readable only by the restricted
        # recovery worker.  Members carry scope so the worker can load the
        # authoritative proposal record and claim a lease atomically.
        refund_recovery_due: str = "agentscope:refund-recovery:due"
        outbox_event: str = "agentscope:outbox:event:{event_id}"
        outbox_pending: str = "agentscope:outbox:pending"

        knowledge_base: str = (
            "agentscope:user:{user_id}:knowledge_base:{knowledge_base_id}"
        )
        knowledge_base_index: str = "agentscope:user:{user_id}:knowledge_bases"

        # Knowledge document keys
        knowledge_document: str = (
            "agentscope:user:{user_id}"
            ":knowledge_base:{knowledge_base_id}"
            ":document:{document_id}"
        )
        knowledge_document_index: str = (
            "agentscope:user:{user_id}"
            ":knowledge_base:{knowledge_base_id}:documents"
        )
        # Global index of every document key as ``user_id:kb_id:doc_id``;
        # used by the lease sweeper, never by per-user listing.
        knowledge_document_global_index: str = "agentscope:knowledge_documents"

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: str | None = None,
        connection_pool: ConnectionPool | None = None,
        key_ttl: int | None = None,
        key_config: "RedisStorage.KeyConfig | None" = None,
        **kwargs: Any,
    ) -> None:
        """Store connection parameters; the actual pool is created in
        :meth:`__aenter__`.

        Args:
            host (`str`, defaults to `"localhost"`): Redis server host.
            port (`int`, defaults to `6379`): Redis server port.
            db (`int`, defaults to `0`): Redis database index.
            password (`str | None`, optional): Redis password if required.
            connection_pool (`ConnectionPool | None`, optional):
                An externally managed connection pool.  When provided the pool
                is used as-is and **not** closed by :meth:`aclose` — the
                caller retains ownership of its lifecycle.  When omitted a
                pool is created from *host*/*port*/*db*/*password* on
                :meth:`__aenter__` and closed on :meth:`aclose`.
                Extra ``**kwargs`` (e.g. ``max_connections``) are forwarded to
                the pool constructor only when the pool is created internally.
            key_ttl (`int | None`, optional):
                Expire time in seconds for record keys. Refreshed on every
                write (sliding TTL). If `None`, keys do not expire.
            key_config (`RedisStorage.KeyConfig | None`, optional):
                Key template configuration. Defaults to
                ``RedisStorage.KeyConfig()``.
            **kwargs (`Any`):
                Extra keyword arguments forwarded to
                ``redis.asyncio.ConnectionPool`` when the pool is created
                internally (e.g. ``max_connections=20``, ``socket_timeout=5``).
        """
        self._host = host
        self._port = port
        self._db = db
        self._password = password
        self._external_pool: ConnectionPool | None = connection_pool
        self._kwargs = kwargs
        self.key_ttl = key_ttl
        self.key_config = key_config or RedisStorage.KeyConfig()

        # Populated in __aenter__; None until the context is entered.
        self._client: Redis | None = None
        self._owned_pool: ConnectionPool | None = None

    def _key(self, template: str, **kwargs: str) -> str:
        """Format a key template with the given keyword arguments."""
        return template.format(**kwargs)

    async def _set_with_ttl(self, key: str, value: str) -> None:
        """SET a key and optionally apply the sliding TTL."""
        await self._client.set(key, value)
        await self._refresh_key_ttl(key)

    async def _refresh_key_ttl(self, key: str) -> None:
        """Apply the sliding TTL to a key, if configured."""
        if self.key_ttl is not None:
            await self._client.expire(key, self.key_ttl)

    def _new_refund_state_event(
        self,
        proposal: RefundProposalRecord,
        *,
        occurred_at: datetime,
    ) -> OutboxEventRecord:
        """Build a scope-bound state event before the Redis transaction."""
        if occurred_at.tzinfo is None:
            occurred_at = occurred_at.replace(tzinfo=timezone.utc)
        else:
            occurred_at = occurred_at.astimezone(timezone.utc)
        return OutboxEventRecord(
            event_type="refund_operation_state_changed",
            tenant_id=proposal.tenant_id,
            customer_id=proposal.customer_id,
            session_id=proposal.session_id,
            operation_id=proposal.operation_id,
            status=proposal.status.value,
            state_version=proposal.state_version,
            occurred_at=occurred_at,
        )

    def _queue_outbox_event(
        self,
        pipe: Any,
        event: OutboxEventRecord,
    ) -> None:
        """Add outbox record and pending index to the same transaction."""
        event_key = self._key(
            self.key_config.outbox_event,
            event_id=event.event_id,
        )
        pipe.set(event_key, event.model_dump_json())
        pipe.sadd(self.key_config.outbox_pending, event.event_id)

    async def __aenter__(self) -> Self:
        """Create the connection pool and Redis client.

        If an external pool was supplied at construction time it is used
        directly and its lifecycle remains the caller's responsibility.
        Otherwise, an internal pool is created from the stored host/port/db
        parameters and will be closed by :meth:`aclose`.
        """
        try:
            import redis.asyncio as aioredis
        except ImportError as e:
            raise ImportError(
                "The 'redis' package is required for RedisStorage. "
                "Install it with: pip install redis[async]",
            ) from e

        if self._external_pool is not None:
            pool = self._external_pool
        else:
            self._owned_pool = aioredis.ConnectionPool(
                host=self._host,
                port=self._port,
                db=self._db,
                password=self._password,
                decode_responses=True,
                **self._kwargs,
            )
            pool = self._owned_pool

        self._client = aioredis.Redis(connection_pool=pool)
        return self

    async def aclose(self) -> None:
        """Close the connection pool if it was created internally.

        Externally supplied pools are left open — the caller owns them.
        """
        if self._owned_pool is not None:
            await self._owned_pool.aclose()
            self._owned_pool = None
        self._client = None

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: Any,
    ) -> None:
        """Exit the async context manager."""
        await self.aclose()

    def get_client(self) -> Redis:
        """Get the underlying Redis client instance."""
        return self._client

    async def _generate_credential_name(
        self,
        user_id: str,
        credential_data: CredentialBase,
    ) -> str:
        """Auto-generate a display name for a credential based on its type.

        Produces names like "OpenAI", "OpenAI (2)", "OpenAI (3)", etc.
        """
        cred_type = getattr(credential_data, "type", "")
        base_name = (
            cred_type.removesuffix("_credential").replace("_", " ").title()
        )
        if not base_name:
            base_name = "Credential"

        existing = await self.list_credentials(user_id)
        same_type_names = [
            c.data.get("name", "")
            for c in existing
            if c.data.get("type") == cred_type and c.id != credential_data.id
        ]

        if base_name not in same_type_names:
            return base_name

        idx = 2
        while f"{base_name} ({idx})" in same_type_names:
            idx += 1
        return f"{base_name} ({idx})"

    async def upsert_credential(
        self,
        user_id: str,
        credential_data: CredentialBase,
    ) -> str:
        """Create or update a credential record for the given user.

        If `credential_data.id` is set and the record already exists, the
        existing record's `data` field is updated in place (preserving
        `created_at`). If the id is set but no record exists, a new record is
        created with that id. If `credential_data.id` is ``None``, a new
        record with a generated id is always created.

        Args:
            user_id (`str`):
                The owner user id.
            credential_data (`CredentialBase`):
                Input data containing an optional `id` and the credential
                `data` dict.

        Returns:
            `str`:
                The id of the created or updated credential record.
        """
        if not credential_data.name:
            credential_data.name = await self._generate_credential_name(
                user_id,
                credential_data,
            )

        data_dump = _dump_with_secrets(credential_data)

        if credential_data.id:
            key = self._key(
                self.key_config.credential,
                user_id=user_id,
                credential_id=credential_data.id,
            )
            raw = await self._client.get(key)
            if raw:
                record = CredentialRecord.model_validate_json(raw)
                record.data = data_dump
                record.updated_at = datetime.now()
            else:
                record = CredentialRecord(
                    id=credential_data.id,
                    user_id=user_id,
                    data=data_dump,
                )
        else:
            record = CredentialRecord(
                user_id=user_id,
                data=data_dump,
            )

        key = self._key(
            self.key_config.credential,
            user_id=user_id,
            credential_id=record.id,
        )
        index_key = self._key(
            self.key_config.credential_index,
            user_id=user_id,
        )
        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(index_key, record.id)
        return record.id

    async def list_credentials(self, user_id: str) -> list[CredentialRecord]:
        """Return all credential records belonging to the given user.

        Reads the per-user credential index Set to obtain all ids, then
        fetches each record individually. Records whose keys have expired or
        been deleted externally are silently skipped.

        Args:
            user_id (`str`): The owner user id.

        Returns:
            `list[CredentialRecord]`: All credential records for the user.
        """
        index_key = self._key(
            self.key_config.credential_index,
            user_id=user_id,
        )
        ids = await self._client.smembers(index_key)
        records = []
        for cred_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.credential,
                    user_id=user_id,
                    credential_id=cred_id,
                ),
            )
            if raw:
                records.append(CredentialRecord.model_validate_json(raw))
        return records

    async def get_credential(
        self,
        user_id: str,
        credential_id: str,
    ) -> CredentialRecord | None:
        """Fetch a single credential record by id."""
        key = self._key(
            self.key_config.credential,
            user_id=user_id,
            credential_id=credential_id,
        )
        raw = await self._client.get(key)
        return CredentialRecord.model_validate_json(raw) if raw else None

    async def delete_credential(
        self,
        user_id: str,
        credential_id: str,
    ) -> bool:
        """Delete a credential record and remove it from the user's index.

        Args:
            user_id (`str`): The owner user id.
            credential_id (`str`): The id of the credential to delete.

        Returns:
            `bool`: ``True`` if the record existed and was deleted,
            ``False`` if it did not exist.
        """
        key = self._key(
            self.key_config.credential,
            user_id=user_id,
            credential_id=credential_id,
        )
        index_key = self._key(
            self.key_config.credential_index,
            user_id=user_id,
        )
        deleted = await self._client.delete(key)
        await self._client.srem(index_key, credential_id)
        return deleted > 0

    async def upsert_mcp(self, user_id: str, mcp_record: MCPRecord) -> str:
        """Create or update an installed-MCP record for the given user.

        Keeps the name index in step with the write: the name is claimed
        for this record, and a rename releases the old one. A name held
        by a different record is rejected outright — the workspace
        relation joins on name, so two records sharing one would make
        that join ambiguous.

        Args:
            user_id (`str`): The owner user id.
            mcp_record (`MCPRecord`): The record to write.

        Returns:
            `str`: The id of the created or updated record.

        Raises:
            `ValueError`: When another record already uses the name.
        """
        name_key = self._key(
            self.key_config.mcp_name_index,
            user_id=user_id,
        )
        holder = await self._client.hget(name_key, mcp_record.client.name)
        if holder is not None and holder != mcp_record.id:
            raise ValueError(
                f"An MCP named {mcp_record.client.name!r} already exists "
                f"for this user.",
            )

        key = self._key(
            self.key_config.mcp,
            user_id=user_id,
            mcp_id=mcp_record.id,
        )
        raw = await self._client.get(key)

        mcp_record.user_id = user_id
        if raw:
            mcp_record.updated_at = datetime.now()

        await self._set_with_ttl(key, mcp_record.model_dump_json())
        await self._client.sadd(
            self._key(self.key_config.mcp_index, user_id=user_id),
            mcp_record.id,
        )
        await self._client.hset(
            name_key,
            mcp_record.client.name,
            mcp_record.id,
        )

        if raw:
            previous = MCPRecord.model_validate_json(raw).client.name
            if previous != mcp_record.client.name:
                await self._client.hdel(name_key, previous)

        return mcp_record.id

    async def list_mcps(self, user_id: str) -> list[MCPRecord]:
        """Return every installed-MCP record belonging to the user.

        Args:
            user_id (`str`): The owner user id.

        Returns:
            `list[MCPRecord]`: All installed-MCP records for the user.
        """
        index_key = self._key(self.key_config.mcp_index, user_id=user_id)
        ids = await self._client.smembers(index_key)
        records = []
        for mcp_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.mcp,
                    user_id=user_id,
                    mcp_id=mcp_id,
                ),
            )
            if raw:
                records.append(MCPRecord.model_validate_json(raw))
        return records

    async def get_mcp(self, user_id: str, mcp_id: str) -> MCPRecord | None:
        """Fetch a single installed-MCP record by id."""
        key = self._key(
            self.key_config.mcp,
            user_id=user_id,
            mcp_id=mcp_id,
        )
        raw = await self._client.get(key)
        return MCPRecord.model_validate_json(raw) if raw else None

    async def get_mcp_by_name(
        self,
        user_id: str,
        name: str,
    ) -> MCPRecord | None:
        """Fetch an installed-MCP record by its MCP name."""
        mcp_id = await self._client.hget(
            self._key(self.key_config.mcp_name_index, user_id=user_id),
            name,
        )
        return await self.get_mcp(user_id, mcp_id) if mcp_id else None

    async def delete_mcp(self, user_id: str, mcp_id: str) -> bool:
        """Delete an installed-MCP record and drop it from both indexes.

        Args:
            user_id (`str`): The owner user id.
            mcp_id (`str`): The id of the record to delete.

        Returns:
            `bool`: ``True`` if the record existed and was deleted.
        """
        record = await self.get_mcp(user_id, mcp_id)

        deleted = await self._client.delete(
            self._key(
                self.key_config.mcp,
                user_id=user_id,
                mcp_id=mcp_id,
            ),
        )
        await self._client.srem(
            self._key(self.key_config.mcp_index, user_id=user_id),
            mcp_id,
        )
        if record:
            await self._client.hdel(
                self._key(self.key_config.mcp_name_index, user_id=user_id),
                record.client.name,
            )
        return deleted > 0

    async def upsert_skill(
        self,
        user_id: str,
        skill_record: SkillRecord,
    ) -> str:
        """Create or update an installed-skill record for the user.

        Mirrors :meth:`upsert_mcp` — see it for the name-index rules.

        Args:
            user_id (`str`): The owner user id.
            skill_record (`SkillRecord`): The record to write.

        Returns:
            `str`: The id of the created or updated record.

        Raises:
            `ValueError`: When another record already uses the name.
        """
        name_key = self._key(
            self.key_config.skill_name_index,
            user_id=user_id,
        )
        holder = await self._client.hget(name_key, skill_record.name)
        if holder is not None and holder != skill_record.id:
            raise ValueError(
                f"A skill named {skill_record.name!r} already exists for "
                f"this user.",
            )

        key = self._key(
            self.key_config.skill,
            user_id=user_id,
            skill_id=skill_record.id,
        )
        raw = await self._client.get(key)

        skill_record.user_id = user_id
        if raw:
            skill_record.updated_at = datetime.now()

        await self._set_with_ttl(key, skill_record.model_dump_json())
        await self._client.sadd(
            self._key(self.key_config.skill_index, user_id=user_id),
            skill_record.id,
        )
        await self._client.hset(name_key, skill_record.name, skill_record.id)

        if raw:
            previous = SkillRecord.model_validate_json(raw).name
            if previous != skill_record.name:
                await self._client.hdel(name_key, previous)

        return skill_record.id

    async def list_skills(self, user_id: str) -> list[SkillRecord]:
        """Return every installed-skill record belonging to the user.

        Args:
            user_id (`str`): The owner user id.

        Returns:
            `list[SkillRecord]`: All installed-skill records for the user.
        """
        index_key = self._key(self.key_config.skill_index, user_id=user_id)
        ids = await self._client.smembers(index_key)
        records = []
        for skill_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.skill,
                    user_id=user_id,
                    skill_id=skill_id,
                ),
            )
            if raw:
                records.append(SkillRecord.model_validate_json(raw))
        return records

    async def get_skill(
        self,
        user_id: str,
        skill_id: str,
    ) -> SkillRecord | None:
        """Fetch a single installed-skill record by id."""
        key = self._key(
            self.key_config.skill,
            user_id=user_id,
            skill_id=skill_id,
        )
        raw = await self._client.get(key)
        return SkillRecord.model_validate_json(raw) if raw else None

    async def get_skill_by_name(
        self,
        user_id: str,
        name: str,
    ) -> SkillRecord | None:
        """Fetch an installed-skill record by its skill name."""
        skill_id = await self._client.hget(
            self._key(self.key_config.skill_name_index, user_id=user_id),
            name,
        )
        if not skill_id:
            return None
        return await self.get_skill(user_id, skill_id)

    async def delete_skill(
        self,
        user_id: str,
        skill_id: str,
    ) -> bool:
        """Delete an installed-skill record and drop both index entries.

        Args:
            user_id (`str`): The owner user id.
            skill_id (`str`): The id of the record to delete.

        Returns:
            `bool`: ``True`` if the record existed and was deleted.
        """
        record = await self.get_skill(user_id, skill_id)

        deleted = await self._client.delete(
            self._key(
                self.key_config.skill,
                user_id=user_id,
                skill_id=skill_id,
            ),
        )
        await self._client.srem(
            self._key(self.key_config.skill_index, user_id=user_id),
            skill_id,
        )
        if record:
            await self._client.hdel(
                self._key(
                    self.key_config.skill_name_index,
                    user_id=user_id,
                ),
                record.name,
            )
        return deleted > 0

    async def upsert_agent(
        self,
        user_id: str,
        agent_record: AgentRecord,
    ) -> str:
        """Persist an agent record and register it in the user's agent index.

        The caller is responsible for constructing the full `AgentRecord`
        (including its `id`). If a record with the same id already exists it
        will be overwritten.

        Args:
            user_id (`str`):
                The owner user id.
            agent_record (`AgentRecord`):
                The fully-populated agent record to store.

        Returns:
            `str`:
                The id of the stored agent record.
        """
        key = self._key(
            self.key_config.agent,
            user_id=user_id,
            agent_id=agent_record.id,
        )
        index_key = self._key(self.key_config.agent_index, user_id=user_id)
        await self._set_with_ttl(key, agent_record.model_dump_json())
        await self._client.sadd(index_key, agent_record.id)
        return agent_record.id

    async def list_agents(self, user_id: str) -> list[AgentRecord]:
        """Return user-facing agent records (``source='user'``).

        Reads the per-user agent index Set to obtain all ids, fetches
        each record individually, and **filters out team-spawned
        workers** (``source='team'``) — those are scoped to a team
        and only addressable via team detail / direct id lookup, not
        enumerated as part of the user's regular agent list.

        Records whose keys have expired or been deleted externally
        are silently skipped.

        Args:
            user_id (`str`): The owner user id.

        Returns:
            `list[AgentRecord]`:
                All ``source='user'`` agent records for the user.
        """
        index_key = self._key(self.key_config.agent_index, user_id=user_id)
        ids = await self._client.smembers(index_key)
        records = []
        for agent_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.agent,
                    user_id=user_id,
                    agent_id=agent_id,
                ),
            )
            if raw:
                record = AgentRecord.model_validate_json(raw)
                if record.source == "user":
                    records.append(record)
        return records

    async def get_agent(
        self,
        user_id: str,
        agent_id: str,
    ) -> AgentRecord | None:
        """Fetch a single agent record by id."""
        key = self._key(
            self.key_config.agent,
            user_id=user_id,
            agent_id=agent_id,
        )
        raw = await self._client.get(key)
        return AgentRecord.model_validate_json(raw) if raw else None

    async def delete_agent(self, user_id: str, agent_id: str) -> bool:
        """Delete an agent record and cascade-delete its sessions,
        schedules, and any team back-references.

        Cascade order:

        1. **Sessions** — every session belonging to this agent is
           deleted via :meth:`delete_session` (which itself cascades
           message log, schedule-session index, and — if a session leads
           a team — the team).
        2. **Schedules** — every schedule whose ``data.agent_id`` matches
           is deleted via :meth:`delete_schedule`.
        3. **Team back-references (defensive)** — if the caller chose to
           delete the agent directly instead of going through
           :meth:`delete_team`, scan the user's teams and remove the
           agent id from both the legacy :attr:`TeamData.member_ids`
           list *and* the current :attr:`TeamData.members` list. The
           normal path (``delete_team`` iterates members and calls
           ``delete_agent`` / ``delete_session`` for each) does not
           need this scan, but it keeps team records consistent if a
           caller bypasses it. Applies to invited members too — a stale
           entry pointing at a removed agent would otherwise poison
           ``TeamSay`` routing.
        4. **Agent record + index** — finally delete the agent key and
           remove from the per-user agent index.

        Args:
            user_id (`str`):
                The owner user id.
            agent_id (`str`):
                The id of the agent to delete.

        Returns:
            `bool`:
                ``True`` if the agent record existed and was deleted,
                ``False`` if it did not exist.
        """
        # Cascade: sessions
        sessions = await self.list_sessions(user_id, agent_id)
        for session in sessions:
            await self.delete_session(user_id, agent_id, session.id)

        # Cascade: schedules owned by this agent
        schedules = await self.list_schedules(user_id)
        for schedule in schedules:
            if schedule.agent_id == agent_id:
                await self.delete_schedule(user_id, schedule.id)

        # Defensive: scrub agent_id from any team's member roster.
        # Covers both the legacy ``member_ids`` field and the current
        # ``members`` list (which additionally holds invited entries).
        # The common path (delete_team -> delete_agent / delete_session)
        # is unaffected because the team is being torn down anyway.
        teams = await self.list_teams(user_id)
        for team in teams:
            dirty = False
            if agent_id in team.data.member_ids:
                team.data.member_ids = [
                    mid for mid in team.data.member_ids if mid != agent_id
                ]
                dirty = True
            filtered_members = [
                m for m in team.data.members if m.agent_id != agent_id
            ]
            if len(filtered_members) != len(team.data.members):
                team.data.members = filtered_members
                dirty = True
            if dirty:
                await self.upsert_team(user_id, team)

        key = self._key(
            self.key_config.agent,
            user_id=user_id,
            agent_id=agent_id,
        )
        index_key = self._key(self.key_config.agent_index, user_id=user_id)
        deleted = await self._client.delete(key)
        await self._client.srem(index_key, agent_id)
        return deleted > 0

    async def upsert_session(
        self,
        user_id: str,
        agent_id: str,
        config: SessionConfig,
        state: AgentState | None = None,
        session_id: str | None = None,
        tenant_id: str | None = None,
        customer_id: str | None = None,
        origin: SessionOrigin | None = None,
        source: str | None = None,
        source_schedule_id: str | None = None,
        source_chat_id: str | None = None,
        source_chat_name: str | None = None,
        source_channel_id: str | None = None,
    ) -> SessionRecord:
        """Create or update a session for a (user, agent) pair.

        When *session_id* is provided the existing session is updated.
        When *session_id* is ``None`` a new session is always created.
        """
        if session_id:
            key = self._key(
                self.key_config.session,
                user_id=user_id,
                session_id=session_id,
            )
            raw = await self._client.get(key)
            if raw:
                record = SessionRecord.model_validate_json(raw)
                if (tenant_id, customer_id) != (None, None) and (
                    record.tenant_id,
                    record.customer_id,
                ) != (tenant_id, customer_id):
                    raise ValueError(
                        "Session tenant/customer scope is immutable.",
                    )
                record.config = config
                if state is not None:
                    record.state = state
                record.updated_at = datetime.now()
                await self._set_with_ttl(key, record.model_dump_json())
                return record

        # Use the caller-provided ``session_id`` when given so a
        # "create-if-missing under this id" call (e.g. scheduler's
        # stateful-mode session) lands at the expected key.
        new_id_kwargs = {"id": session_id} if session_id else {}
        record = SessionRecord(
            user_id=user_id,
            agent_id=agent_id,
            tenant_id=tenant_id,
            customer_id=customer_id,
            config=config,
            **_origin_kwargs(
                origin,
                source,
                source_schedule_id,
                source_channel_id,
                source_chat_id,
                source_chat_name,
            ),
            state=state if state is not None else AgentState(),
            **new_id_kwargs,
        )
        key = self._key(
            self.key_config.session,
            user_id=user_id,
            session_id=record.id,
        )
        index_key = self._key(
            self.key_config.session_index,
            user_id=user_id,
            agent_id=agent_id,
        )
        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(index_key, record.id)

        if isinstance(record.origin, ScheduleOrigin):
            schedule_session_key = self._key(
                self.key_config.schedule_session_index,
                user_id=user_id,
                schedule_id=record.origin.schedule_id,
            )
            await self._client.sadd(schedule_session_key, record.id)

        if isinstance(record.origin, ChannelOrigin):
            channel_session_key = self._key(
                self.key_config.channel_session_index,
                user_id=user_id,
                channel_id=record.origin.channel_id,
            )
            await self._client.sadd(channel_session_key, record.id)

        return record

    async def update_session_state(
        self,
        user_id: str,
        agent_id: str,
        session_id: str,
        state: AgentState,
    ) -> None:
        """Update only the mutable state of an existing session.

        Raises:
            KeyError: If the session does not exist.
        """
        key = self._key(
            self.key_config.session,
            user_id=user_id,
            session_id=session_id,
        )
        raw = await self._client.get(key)
        if not raw:
            raise KeyError(f"Session {session_id!r} not found.")
        record = SessionRecord.model_validate_json(raw)
        record.state = state
        record.updated_at = datetime.now()
        await self._set_with_ttl(key, record.model_dump_json())

    async def list_sessions(
        self,
        user_id: str,
        agent_id: str,
    ) -> list[SessionRecord]:
        """Return all session records for a given (user, agent) pair.

        Reads the per-agent session index Set to obtain all session ids, then
        fetches each record individually. Records whose keys have expired or
        been deleted externally are silently skipped.

        Args:
            user_id (`str`): The owner user id.
            agent_id (`str`): The agent id whose sessions to list.

        Returns:
            `list[SessionRecord]`: All session records for the (user, agent)
            pair.
        """
        index_key = self._key(
            self.key_config.session_index,
            user_id=user_id,
            agent_id=agent_id,
        )
        ids = await self._client.smembers(index_key)
        records = []
        for session_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.session,
                    user_id=user_id,
                    session_id=session_id,
                ),
            )
            if raw:
                records.append(SessionRecord.model_validate_json(raw))
        records.sort(key=lambda r: r.created_at, reverse=True)
        return records

    async def get_session(
        self,
        user_id: str,
        agent_id: str,
        session_id: str,
    ) -> SessionRecord | None:
        """Fetch a single session record by id."""
        key = self._key(
            self.key_config.session,
            user_id=user_id,
            session_id=session_id,
        )
        raw = await self._client.get(key)
        if not raw:
            return None
        return SessionRecord.model_validate_json(raw)

    async def delete_session(
        self,
        user_id: str,
        agent_id: str,
        session_id: str,
    ) -> bool:
        """Delete a session record and cascade clean-up.

        Cascades:

        - Existing: per-session message log, schedule-session index entry.
        - **NEW**: if this session is the leader of a team (``team_id``
          set AND a :class:`TeamRecord` exists with
          ``session_id == this session_id``), call :meth:`delete_team`
          first. ``delete_team`` will recursively cascade workers and
          clear ``team_id`` on this session — that clear is idempotent
          and the session itself is deleted right after, so the order is
          safe.

        Worker sessions (``team_id`` set, but the team's
        ``leader_session_id`` is **not** this session) are deleted
        without dissolving the team — the team and the surviving leader
        keep their member_ids list pointing to the now-orphaned worker
        agent. This intentional asymmetry mirrors SQL: there is no FK
        from :class:`SessionRecord` back to the agent that owns it, so
        deleting a session doesn't automatically delete the agent.

        Args:
            user_id (`str`):
                The owner user id.
            agent_id (`str`):
                The id of the agent that owns the session (used to
                clean up the per-agent session index).
            session_id (`str`):
                The id of the session to delete.

        Returns:
            `bool`:
                ``True`` if the session existed and was deleted,
                ``False`` if no record was found.
        """
        key = self._key(
            self.key_config.session,
            user_id=user_id,
            session_id=session_id,
        )
        raw = await self._client.get(key)
        if not raw:
            return False

        record = SessionRecord.model_validate_json(raw)

        # Cascade: if this session leads a team, dissolve it first.
        if record.team_id:
            team = await self.get_team(user_id, record.team_id)
            if team is not None and team.session_id == session_id:
                await self.delete_team(user_id, record.team_id)

        index_key = self._key(
            self.key_config.session_index,
            user_id=user_id,
            agent_id=agent_id,
        )
        msg_key = self._key(
            self.key_config.messages,
            user_id=user_id,
            session_id=session_id,
        )
        await self._client.delete(key)
        await self._client.srem(index_key, session_id)
        await self._client.delete(msg_key)

        if isinstance(record.origin, ScheduleOrigin):
            schedule_session_key = self._key(
                self.key_config.schedule_session_index,
                user_id=user_id,
                schedule_id=record.origin.schedule_id,
            )
            await self._client.srem(schedule_session_key, session_id)

        if isinstance(record.origin, ChannelOrigin):
            channel_session_key = self._key(
                self.key_config.channel_session_index,
                user_id=user_id,
                channel_id=record.origin.channel_id,
            )
            await self._client.srem(channel_session_key, session_id)

        return True

    async def list_sessions_by_schedule(
        self,
        user_id: str,
        schedule_id: str,
    ) -> list[SessionRecord]:
        """Return all sessions created by a given schedule."""
        schedule_session_key = self._key(
            self.key_config.schedule_session_index,
            user_id=user_id,
            schedule_id=schedule_id,
        )
        ids = await self._client.smembers(schedule_session_key)
        records = []
        for session_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.session,
                    user_id=user_id,
                    session_id=session_id,
                ),
            )
            if raw:
                records.append(SessionRecord.model_validate_json(raw))
        records.sort(key=lambda r: r.created_at, reverse=True)
        return records

    async def list_sessions_by_channel(
        self,
        user_id: str,
        channel_id: str,
    ) -> list[SessionRecord]:
        """Return all sessions derived from a given channel."""
        channel_session_key = self._key(
            self.key_config.channel_session_index,
            user_id=user_id,
            channel_id=channel_id,
        )
        ids = await self._client.smembers(channel_session_key)
        records = []
        for session_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.session,
                    user_id=user_id,
                    session_id=session_id,
                ),
            )
            if raw:
                records.append(SessionRecord.model_validate_json(raw))
        records.sort(key=lambda r: r.created_at, reverse=True)
        return records

    async def upsert_ticket(self, record: TicketRecord) -> str:
        """Persist a ticket under its immutable tenant/customer scope."""
        key = self._key(
            self.key_config.ticket,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
            ticket_id=record.id,
        )
        index_key = self._key(
            self.key_config.ticket_index,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
        )
        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(index_key, record.id)
        return record.id

    async def create_open_ticket_if_absent(
        self,
        record: TicketRecord,
        *,
        idempotency_key: str | None = None,
        request_fingerprint: str | None = None,
    ) -> tuple[str, TicketRecord | None]:
        """Create one OPEN ticket atomically for a scoped order.

        The scoped ``ticket_open`` key and optional idempotency key are watched
        while the record, ticket index, and markers are committed in one
        Redis transaction. A competing writer therefore either observes the
        existing marker or retries after Redis aborts its transaction.
        """
        if (idempotency_key is None) != (request_fingerprint is None):
            raise ValueError(
                "Idempotency key and request fingerprint must be paired.",
            )
        ticket_key = self._key(
            self.key_config.ticket,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
            ticket_id=record.id,
        )
        index_key = self._key(
            self.key_config.ticket_index,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
        )
        open_key = self._key(
            self.key_config.ticket_open,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
            order_id=record.order_id,
        )
        request_key = None
        if idempotency_key is not None:
            request_key = self._key(
                self.key_config.ticket_idempotency,
                tenant_id=record.tenant_id,
                customer_id=record.customer_id,
                requester_user_id=record.requester_user_id,
                operation="create_ticket",
                idempotency_key=idempotency_key,
            )
        request_value = None
        if request_fingerprint is not None:
            request_value = json.dumps(
                {
                    "fingerprint": request_fingerprint,
                    "ticket_id": record.id,
                },
                ensure_ascii=False,
                separators=(",", ":"),
            )

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    watched_keys = [open_key]
                    if request_key is not None:
                        watched_keys.append(request_key)
                    await pipe.watch(*watched_keys)

                    existing_request = None
                    if request_key is not None:
                        existing_request = await pipe.get(request_key)
                    if existing_request is not None:
                        request_data = json.loads(existing_request)
                        existing_id = str(request_data["ticket_id"])
                        existing = await self.get_ticket(
                            record.tenant_id,
                            record.customer_id,
                            existing_id,
                        )
                        await pipe.unwatch()
                        if existing is None:
                            raise RuntimeError(
                                "Idempotency record points to a missing "
                                "ticket record.",
                            )
                        if request_data["fingerprint"] != request_fingerprint:
                            return "conflict", existing
                        return "replayed", existing

                    existing_id = await pipe.get(open_key)
                    if existing_id is not None:
                        existing = await self.get_ticket(
                            record.tenant_id,
                            record.customer_id,
                            str(existing_id),
                        )
                        if existing is None:
                            await pipe.unwatch()
                            raise RuntimeError(
                                "Redis ticket uniqueness marker points to "
                                "a missing ticket record.",
                            )
                        if request_key is not None and request_value is not None:
                            pipe.multi()
                            pipe.set(request_key, request_value)
                            if self.key_ttl is not None:
                                pipe.expire(request_key, self.key_ttl)
                            await pipe.execute()
                        else:
                            await pipe.unwatch()
                        return "existing", existing

                    pipe.multi()
                    pipe.set(ticket_key, record.model_dump_json())
                    pipe.sadd(index_key, record.id)
                    pipe.set(open_key, record.id)
                    if request_key is not None and request_value is not None:
                        pipe.set(request_key, request_value)
                    if self.key_ttl is not None:
                        pipe.expire(ticket_key, self.key_ttl)
                        pipe.expire(open_key, self.key_ttl)
                        if request_key is not None:
                            pipe.expire(request_key, self.key_ttl)
                    await pipe.execute()
                    return "created", record
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not atomically create the ticket after Redis contention.",
        )

    async def get_ticket(
        self,
        tenant_id: str,
        customer_id: str,
        ticket_id: str,
    ) -> TicketRecord | None:
        """Fetch a ticket only through its tenant/customer-scoped key."""
        key = self._key(
            self.key_config.ticket,
            tenant_id=tenant_id,
            customer_id=customer_id,
            ticket_id=ticket_id,
        )
        raw = await self._client.get(key)
        return TicketRecord.model_validate_json(raw) if raw else None

    async def list_tickets(
        self,
        tenant_id: str,
        customer_id: str,
    ) -> list[TicketRecord]:
        """List tickets from one tenant/customer-scoped index."""
        index_key = self._key(
            self.key_config.ticket_index,
            tenant_id=tenant_id,
            customer_id=customer_id,
        )
        ids = await self._client.smembers(index_key)
        records = []
        for ticket_id in ids:
            record = await self.get_ticket(
                tenant_id,
                customer_id,
                ticket_id,
            )
            if record is not None:
                records.append(record)
        records.sort(key=lambda r: r.created_at, reverse=True)
        return records

    async def find_open_ticket(
        self,
        tenant_id: str,
        customer_id: str,
        order_id: str,
    ) -> TicketRecord | None:
        """Find an OPEN ticket only inside one customer scope."""
        for record in await self.list_tickets(tenant_id, customer_id):
            if (
                record.order_id == order_id
                and record.status is TicketStatus.OPEN
            ):
                return record
        return None

    async def get_refund_proposal(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
    ) -> RefundProposalRecord | None:
        """Fetch a proposal only through its tenant/customer-scoped key."""
        key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )
        raw = await self._client.get(key)
        return RefundProposalRecord.model_validate_json(raw) if raw else None

    async def list_refund_proposals_for_session(
        self,
        tenant_id: str,
        customer_id: str,
        session_id: str,
    ) -> list[RefundProposalRecord]:
        """List proposals for one session without widening its scope."""
        index_key = self._key(
            self.key_config.refund_proposal_session_index,
            tenant_id=tenant_id,
            customer_id=customer_id,
            session_id=session_id,
        )
        operation_ids = await self._client.smembers(index_key)
        records: list[RefundProposalRecord] = []
        for raw_operation_id in operation_ids:
            record = await self.get_refund_proposal(
                tenant_id,
                customer_id,
                str(raw_operation_id),
            )
            if record is not None and record.session_id == session_id:
                records.append(record)
        records.sort(key=lambda item: item.updated_at, reverse=True)
        return records

    async def create_refund_proposal_if_absent(
        self,
        record: RefundProposalRecord,
        *,
        idempotency_key: str,
        request_fingerprint: str,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Atomically create one active refund proposal in a scope."""
        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
            operation_id=record.operation_id,
        )
        index_key = self._key(
            self.key_config.refund_proposal_index,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
        )
        session_index_key = self._key(
            self.key_config.refund_proposal_session_index,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
            session_id=record.session_id,
        )
        active_key = self._key(
            self.key_config.refund_proposal_active,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
            order_id=record.order_id,
        )
        request_key = self._key(
            self.key_config.refund_proposal_idempotency,
            tenant_id=record.tenant_id,
            customer_id=record.customer_id,
            requester_user_id=record.requester_user_id,
            idempotency_key=idempotency_key,
        )
        request_value = json.dumps(
            {
                "fingerprint": request_fingerprint,
                "operation_id": record.operation_id,
            },
            ensure_ascii=False,
            separators=(",", ":"),
        )

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(active_key, request_key)
                    existing_request = await pipe.get(request_key)
                    if existing_request is not None:
                        request_data = json.loads(existing_request)
                        existing = await self.get_refund_proposal(
                            record.tenant_id,
                            record.customer_id,
                            str(request_data["operation_id"]),
                        )
                        await pipe.unwatch()
                        if existing is None:
                            raise RuntimeError(
                                "Idempotency record points to a missing "
                                "refund proposal.",
                            )
                        if request_data["fingerprint"] != request_fingerprint:
                            return "conflict", existing
                        return "replayed", existing

                    existing_id = await pipe.get(active_key)
                    if existing_id is not None:
                        existing = await self.get_refund_proposal(
                            record.tenant_id,
                            record.customer_id,
                            str(existing_id),
                        )
                        await pipe.unwatch()
                        if existing is None:
                            raise RuntimeError(
                                "Refund proposal marker points to a missing "
                                "record.",
                            )
                        return "existing", existing

                    event = self._new_refund_state_event(
                        record,
                        occurred_at=record.updated_at,
                    )
                    pipe.multi()
                    pipe.set(proposal_key, record.model_dump_json())
                    pipe.sadd(index_key, record.operation_id)
                    pipe.sadd(session_index_key, record.operation_id)
                    pipe.set(active_key, record.operation_id)
                    pipe.set(request_key, request_value)
                    self._queue_outbox_event(pipe, event)
                    if self.key_ttl is not None:
                        pipe.expire(proposal_key, self.key_ttl)
                        pipe.expire(session_index_key, self.key_ttl)
                        pipe.expire(active_key, self.key_ttl)
                        pipe.expire(request_key, self.key_ttl)
                    await pipe.execute()
                    return "created", record
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not atomically create the refund proposal after "
            "Redis contention.",
        )

    async def transition_refund_proposal(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        *,
        expected_status: RefundProposalStatus,
        next_status: RefundProposalStatus,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Compare-and-set a proposal status inside its customer scope."""
        if expected_status is next_status:
            raise ValueError("Proposal status transition must change state.")
        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(proposal_key)
                    raw = await pipe.get(proposal_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None

                    proposal = RefundProposalRecord.model_validate_json(raw)
                    if proposal.status is not expected_status:
                        await pipe.unwatch()
                        return "current", proposal

                    updated = proposal.model_copy(
                        update={
                            "status": next_status,
                            "state_version": proposal.state_version + 1,
                            "record_version": proposal.record_version + 1,
                        },
                    )
                    event = self._new_refund_state_event(
                        updated,
                        occurred_at=datetime.now(),
                    )
                    pipe.multi()
                    pipe.set(proposal_key, updated.model_dump_json())
                    self._queue_outbox_event(pipe, event)
                    await pipe.execute()
                    return "transitioned", updated
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not transition the refund proposal after Redis "
            "contention.",
        )

    async def approve_refund_proposal(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        *,
        approver_user_id: str,
        approved_at: datetime,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Atomically approve one proposal and record the staff actor."""
        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(proposal_key)
                    raw = await pipe.get(proposal_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None

                    proposal = RefundProposalRecord.model_validate_json(raw)
                    if proposal.status is not RefundProposalStatus.PENDING_STAFF_APPROVAL:
                        await pipe.unwatch()
                        return "current", proposal

                    updated = proposal.model_copy(
                        update={
                            "status": RefundProposalStatus.APPROVED,
                            "state_version": proposal.state_version + 1,
                            "record_version": proposal.record_version + 1,
                            "staff_approved_by_user_id": approver_user_id,
                            "staff_approved_at": approved_at,
                        },
                    )
                    event = self._new_refund_state_event(
                        updated,
                        occurred_at=approved_at,
                    )
                    pipe.multi()
                    pipe.set(proposal_key, updated.model_dump_json())
                    self._queue_outbox_event(pipe, event)
                    await pipe.execute()
                    return "approved", updated
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not approve the refund proposal after Redis contention.",
        )

    async def start_refund_execution(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        *,
        execution_attempt_id: str,
        provider_idempotency_key: str,
        started_at: datetime,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Atomically claim an APPROVED proposal for one execution attempt."""
        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )
        attempt_key = self._key(
            self.key_config.refund_execution_attempt,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
            execution_attempt_id=execution_attempt_id,
        )
        attempt_index_key = self._key(
            self.key_config.refund_execution_attempt_index,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(proposal_key, attempt_key)
                    raw = await pipe.get(proposal_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None

                    proposal = RefundProposalRecord.model_validate_json(raw)
                    if proposal.status not in {
                        RefundProposalStatus.APPROVED,
                        RefundProposalStatus.READY_TO_RETRY,
                    }:
                        await pipe.unwatch()
                        return "current", proposal

                    if await pipe.get(attempt_key) is not None:
                        await pipe.unwatch()
                        raise RuntimeError(
                            "Refund execution attempt id already exists.",
                        )

                    attempt = RefundExecutionAttemptRecord(
                        id=execution_attempt_id,
                        tenant_id=tenant_id,
                        customer_id=customer_id,
                        operation_id=operation_id,
                        attempt_number=proposal.execution_attempts + 1,
                        provider_idempotency_key=provider_idempotency_key,
                        started_at=started_at,
                        created_at=started_at,
                        updated_at=started_at,
                    )

                    updated = proposal.model_copy(
                        update={
                            "status": RefundProposalStatus.EXECUTING,
                            "state_version": proposal.state_version + 1,
                            "record_version": proposal.record_version + 1,
                            "execution_attempts": (
                                proposal.execution_attempts + 1
                            ),
                            "latest_execution_attempt_id": (
                                execution_attempt_id
                            ),
                            "external_request_id": None,
                            "execution_started_at": started_at,
                            "last_attempt_at": started_at,
                            "last_error_type": None,
                            "last_error": None,
                        },
                    )
                    event = self._new_refund_state_event(
                        updated,
                        occurred_at=started_at,
                    )
                    pipe.multi()
                    pipe.set(proposal_key, updated.model_dump_json())
                    pipe.set(attempt_key, attempt.model_dump_json())
                    pipe.sadd(attempt_index_key, execution_attempt_id)
                    self._queue_outbox_event(pipe, event)
                    if self.key_ttl is not None:
                        pipe.expire(proposal_key, self.key_ttl)
                        pipe.expire(attempt_key, self.key_ttl)
                    await pipe.execute()
                    return "started", updated
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not start refund execution after Redis contention.",
        )

    async def finish_refund_execution(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        *,
        execution_attempt_id: str,
        expected_status: RefundProposalStatus,
        next_status: RefundProposalStatus,
        finished_at: datetime,
        external_request_id: str | None = None,
        last_error_type: str | None = None,
        last_error: str | None = None,
        expected_recovery_lease_token: str | None = None,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Atomically persist one terminal or UNKNOWN execution result."""
        if next_status not in {
            RefundProposalStatus.SUCCEEDED,
            RefundProposalStatus.FAILED,
            RefundProposalStatus.UNKNOWN,
        }:
            raise ValueError("Refund execution must finish in a result state.")
        if expected_status not in {
            RefundProposalStatus.EXECUTING,
            RefundProposalStatus.UNKNOWN,
        }:
            raise ValueError("Unexpected refund execution source state.")
        if expected_status is next_status:
            raise ValueError("Refund execution transition must change state.")

        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )
        attempt_key = self._key(
            self.key_config.refund_execution_attempt,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
            execution_attempt_id=execution_attempt_id,
        )
        recovery_due_key = self.key_config.refund_recovery_due

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(proposal_key, attempt_key)
                    raw = await pipe.get(proposal_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None

                    proposal = RefundProposalRecord.model_validate_json(raw)
                    if proposal.status is not expected_status:
                        await pipe.unwatch()
                        return "current", proposal
                    if (
                        expected_recovery_lease_token is not None
                        and proposal.recovery_lease_token
                        != expected_recovery_lease_token
                    ):
                        await pipe.unwatch()
                        return "lease_lost", proposal

                    attempt_raw = await pipe.get(attempt_key)
                    if attempt_raw is None:
                        await pipe.unwatch()
                        raise RuntimeError(
                            "Refund execution attempt is missing.",
                        )
                    attempt = RefundExecutionAttemptRecord.model_validate_json(
                        attempt_raw,
                    )
                    expected_attempt_status = (
                        RefundExecutionAttemptStatus.EXECUTING
                        if expected_status is RefundProposalStatus.EXECUTING
                        else RefundExecutionAttemptStatus.UNKNOWN
                    )
                    if attempt.status is not expected_attempt_status:
                        await pipe.unwatch()
                        return "current", proposal

                    attempt_status = {
                        RefundProposalStatus.SUCCEEDED:
                            RefundExecutionAttemptStatus.SUCCEEDED,
                        RefundProposalStatus.FAILED:
                            RefundExecutionAttemptStatus.FAILED,
                        RefundProposalStatus.UNKNOWN:
                            RefundExecutionAttemptStatus.UNKNOWN,
                    }[next_status]
                    updated_attempt = attempt.model_copy(
                        update={
                            "status": attempt_status,
                            "external_request_id": external_request_id,
                            "finished_at": finished_at,
                            "updated_at": finished_at,
                            "last_error": last_error,
                        },
                    )

                    updated = proposal.model_copy(
                        update={
                            "status": next_status,
                            "state_version": proposal.state_version + 1,
                            "record_version": proposal.record_version + 1,
                            "execution_finished_at": finished_at,
                            "external_request_id": external_request_id,
                            "last_attempt_at": finished_at,
                            "last_error_type": last_error_type,
                            "last_error": last_error,
                            "next_recovery_at": (
                                finished_at
                                if next_status
                                is RefundProposalStatus.UNKNOWN
                                else None
                            ),
                            "recovery_lease_owner": None,
                            "recovery_lease_token": None,
                            "recovery_lease_expires_at": None,
                        },
                    )
                    event = self._new_refund_state_event(
                        updated,
                        occurred_at=finished_at,
                    )
                    pipe.multi()
                    pipe.set(proposal_key, updated.model_dump_json())
                    pipe.set(attempt_key, updated_attempt.model_dump_json())
                    recovery_member = json.dumps(
                        [
                            tenant_id,
                            customer_id,
                            operation_id,
                        ],
                        separators=(",", ":"),
                    )
                    if next_status is RefundProposalStatus.UNKNOWN:
                        pipe.zadd(
                            recovery_due_key,
                            {recovery_member: finished_at.timestamp()},
                        )
                    else:
                        pipe.zrem(recovery_due_key, recovery_member)
                    self._queue_outbox_event(pipe, event)
                    if self.key_ttl is not None:
                        pipe.expire(proposal_key, self.key_ttl)
                    await pipe.execute()
                    return "finished", updated
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not finish refund execution after Redis contention.",
        )

    async def get_refund_execution_attempt(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        execution_attempt_id: str,
    ) -> RefundExecutionAttemptRecord | None:
        """Fetch one execution attempt through its scoped key."""
        key = self._key(
            self.key_config.refund_execution_attempt,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
            execution_attempt_id=execution_attempt_id,
        )
        raw = await self._client.get(key)
        return (
            RefundExecutionAttemptRecord.model_validate_json(raw)
            if raw
            else None
        )

    async def list_refund_execution_attempts(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
    ) -> list[RefundExecutionAttemptRecord]:
        """List attempts only from one scoped operation index."""
        index_key = self._key(
            self.key_config.refund_execution_attempt_index,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )
        attempt_ids = await self._client.smembers(index_key)
        records: list[RefundExecutionAttemptRecord] = []
        for attempt_id in attempt_ids:
            record = await self.get_refund_execution_attempt(
                tenant_id,
                customer_id,
                operation_id,
                str(attempt_id),
            )
            if record is not None:
                records.append(record)
        records.sort(key=lambda record: record.attempt_number)
        return records

    async def record_refund_status_query_attempt(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        *,
        attempted_at: datetime,
        error_type: str | None = None,
        reconciliation_required: bool = False,
        next_recovery_at: datetime | None = None,
        schedule_recovery: bool = False,
        expected_recovery_lease_token: str | None = None,
        release_recovery_lease: bool = False,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Record recovery metadata without emitting a state event."""
        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(proposal_key)
                    raw = await pipe.get(proposal_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None

                    proposal = RefundProposalRecord.model_validate_json(raw)
                    if (
                        expected_recovery_lease_token is not None
                        and proposal.recovery_lease_token
                        != expected_recovery_lease_token
                    ):
                        await pipe.unwatch()
                        return "lease_lost", proposal
                    updates: dict[str, object] = {
                        "status_query_attempt_count": (
                            proposal.status_query_attempt_count + 1
                        ),
                        "record_version": proposal.record_version + 1,
                        "last_attempt_at": attempted_at,
                        "last_error_type": error_type,
                        "reconciliation_required": reconciliation_required,
                        "updated_at": attempted_at,
                    }
                    if schedule_recovery or reconciliation_required:
                        updates["next_recovery_at"] = (
                            None
                            if reconciliation_required
                            else next_recovery_at
                        )
                    if release_recovery_lease:
                        updates.update(
                            {
                                "recovery_lease_owner": None,
                                "recovery_lease_token": None,
                                "recovery_lease_expires_at": None,
                            },
                        )
                    updated = proposal.model_copy(
                        update=updates,
                    )
                    pipe.multi()
                    pipe.set(proposal_key, updated.model_dump_json())
                    if schedule_recovery or reconciliation_required:
                        recovery_member = json.dumps(
                            [tenant_id, customer_id, operation_id],
                            separators=(",", ":"),
                        )
                        if reconciliation_required:
                            pipe.zrem(
                                self.key_config.refund_recovery_due,
                                recovery_member,
                            )
                        elif next_recovery_at is not None:
                            pipe.zadd(
                                self.key_config.refund_recovery_due,
                                {recovery_member: next_recovery_at.timestamp()},
                            )
                    if self.key_ttl is not None:
                        pipe.expire(proposal_key, self.key_ttl)
                    await pipe.execute()
                    return "recorded", updated
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not record refund recovery metadata after Redis "
            "contention.",
        )

    async def list_due_refund_recoveries(
        self,
        *,
        now: datetime,
        max_count: int = 100,
    ) -> list[RefundProposalRecord]:
        """Read due work from the system-only recovery index."""
        if max_count <= 0:
            return []
        members = await self._client.zrangebyscore(
            self.key_config.refund_recovery_due,
            "-inf",
            now.timestamp(),
            start=0,
            num=max_count,
        )
        records: list[RefundProposalRecord] = []
        for raw_member in members:
            try:
                tenant_id, customer_id, operation_id = json.loads(
                    str(raw_member),
                )
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            proposal = await self.get_refund_proposal(
                str(tenant_id),
                str(customer_id),
                str(operation_id),
            )
            if (
                proposal is not None
                and proposal.status is RefundProposalStatus.UNKNOWN
                and not proposal.reconciliation_required
                and proposal.next_recovery_at is not None
                and proposal.next_recovery_at <= now
            ):
                records.append(proposal)
        return records

    async def claim_refund_recovery_lease(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        *,
        lease_owner: str,
        lease_token: str,
        now: datetime,
        lease_expires_at: datetime,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Claim a due operation with a token guarded by WATCH."""
        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )
        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(proposal_key)
                    raw = await pipe.get(proposal_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None
                    proposal = RefundProposalRecord.model_validate_json(raw)
                    if (
                        proposal.status is not RefundProposalStatus.UNKNOWN
                        or proposal.reconciliation_required
                        or proposal.next_recovery_at is None
                        or proposal.next_recovery_at > now
                    ):
                        await pipe.unwatch()
                        return "current", proposal
                    if (
                        proposal.recovery_lease_expires_at is not None
                        and proposal.recovery_lease_expires_at > now
                    ):
                        await pipe.unwatch()
                        return "leased", proposal
                    updated = proposal.model_copy(
                        update={
                            "recovery_lease_owner": lease_owner,
                            "recovery_lease_token": lease_token,
                            "recovery_lease_expires_at": lease_expires_at,
                            "record_version": proposal.record_version + 1,
                            "updated_at": now,
                        },
                    )
                    pipe.multi()
                    pipe.set(proposal_key, updated.model_dump_json())
                    if self.key_ttl is not None:
                        pipe.expire(proposal_key, self.key_ttl)
                    await pipe.execute()
                    return "claimed", updated
                except _watch_error():
                    continue
        raise RuntimeError(
            "Could not claim the refund recovery lease after Redis contention.",
        )

    async def reconcile_refund_operation(
        self,
        tenant_id: str,
        customer_id: str,
        operation_id: str,
        *,
        execution_attempt_id: str,
        next_status: RefundProposalStatus,
        reconciler_user_id: str,
        reconciled_at: datetime,
        reconciliation_reason: str,
        reconciliation_evidence_id: str | None = None,
    ) -> tuple[str, RefundProposalRecord | None]:
        """Atomically resolve UNKNOWN from trusted provider evidence."""
        if next_status not in {
            RefundProposalStatus.SUCCEEDED,
            RefundProposalStatus.FAILED,
            RefundProposalStatus.READY_TO_RETRY,
            RefundProposalStatus.EXPIRED,
            RefundProposalStatus.CANCELLED,
        }:
            raise ValueError("Unsupported refund reconciliation state.")
        proposal_key = self._key(
            self.key_config.refund_proposal,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
        )
        attempt_key = self._key(
            self.key_config.refund_execution_attempt,
            tenant_id=tenant_id,
            customer_id=customer_id,
            operation_id=operation_id,
            execution_attempt_id=execution_attempt_id,
        )
        recovery_member = json.dumps(
            [tenant_id, customer_id, operation_id],
            separators=(",", ":"),
        )
        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(proposal_key, attempt_key)
                    raw = await pipe.get(proposal_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None
                    proposal = RefundProposalRecord.model_validate_json(raw)
                    if proposal.status is not RefundProposalStatus.UNKNOWN:
                        await pipe.unwatch()
                        return "current", proposal
                    if (
                        proposal.recovery_lease_expires_at is not None
                        and proposal.recovery_lease_expires_at > reconciled_at
                    ):
                        await pipe.unwatch()
                        return "leased", proposal
                    attempt_raw = await pipe.get(attempt_key)
                    if attempt_raw is None:
                        raise RuntimeError("Refund execution attempt is missing.")
                    attempt = RefundExecutionAttemptRecord.model_validate_json(
                        attempt_raw,
                    )
                    if attempt.status is not RefundExecutionAttemptStatus.UNKNOWN:
                        await pipe.unwatch()
                        return "current", proposal
                    attempt_status = {
                        RefundProposalStatus.SUCCEEDED:
                            RefundExecutionAttemptStatus.SUCCEEDED,
                        RefundProposalStatus.FAILED:
                            RefundExecutionAttemptStatus.FAILED,
                        RefundProposalStatus.READY_TO_RETRY:
                            RefundExecutionAttemptStatus.NOT_ACCEPTED,
                        RefundProposalStatus.EXPIRED:
                            RefundExecutionAttemptStatus.NOT_ACCEPTED,
                        RefundProposalStatus.CANCELLED:
                            RefundExecutionAttemptStatus.NOT_ACCEPTED,
                    }[next_status]
                    updated_attempt = attempt.model_copy(
                        update={
                            "status": attempt_status,
                            "finished_at": reconciled_at,
                            "updated_at": reconciled_at,
                            "last_error": reconciliation_reason,
                        },
                    )
                    updated = proposal.model_copy(
                        update={
                            "status": next_status,
                            "state_version": proposal.state_version + 1,
                            "record_version": proposal.record_version + 1,
                            "reconciliation_required": False,
                            "reconciled_by_user_id": reconciler_user_id,
                            "reconciled_at": reconciled_at,
                            "reconciliation_evidence_id": (
                                reconciliation_evidence_id
                            ),
                            "reconciliation_reason": reconciliation_reason,
                            "next_recovery_at": None,
                            "recovery_lease_owner": None,
                            "recovery_lease_token": None,
                            "recovery_lease_expires_at": None,
                            "last_attempt_at": reconciled_at,
                            "last_error_type": (
                                None
                                if next_status is RefundProposalStatus.SUCCEEDED
                                else "provider_not_accepted"
                                if next_status
                                is RefundProposalStatus.READY_TO_RETRY
                                else "provider_rejected"
                            ),
                            "last_error": (
                                None
                                if next_status is RefundProposalStatus.SUCCEEDED
                                else "退款网关报告执行失败"
                                if next_status is RefundProposalStatus.FAILED
                                else "供应商确认未接收退款请求"
                            ),
                            "updated_at": reconciled_at,
                        },
                    )
                    event = self._new_refund_state_event(
                        updated,
                        occurred_at=reconciled_at,
                    )
                    pipe.multi()
                    pipe.set(proposal_key, updated.model_dump_json())
                    pipe.set(attempt_key, updated_attempt.model_dump_json())
                    pipe.zrem(self.key_config.refund_recovery_due, recovery_member)
                    self._queue_outbox_event(pipe, event)
                    if self.key_ttl is not None:
                        pipe.expire(proposal_key, self.key_ttl)
                        pipe.expire(attempt_key, self.key_ttl)
                    await pipe.execute()
                    return "reconciled", updated
                except _watch_error():
                    continue
        raise RuntimeError(
            "Could not reconcile the refund operation after Redis contention.",
        )

    async def list_pending_outbox_events(
        self,
        max_count: int = 100,
    ) -> list[OutboxEventRecord]:
        """Read pending outbox records from the internal global index."""
        event_ids = await self._client.smembers(
            self.key_config.outbox_pending,
        )
        records: list[OutboxEventRecord] = []
        for event_id in event_ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.outbox_event,
                    event_id=str(event_id),
                ),
            )
            if raw is None:
                continue
            event = OutboxEventRecord.model_validate_json(raw)
            if event.published_at is None:
                records.append(event)
        records.sort(key=lambda event: event.occurred_at)
        return records[:max_count]

    async def mark_outbox_event_published(
        self,
        event_id: str,
        *,
        published_at: datetime,
    ) -> tuple[str, OutboxEventRecord | None]:
        """Mark one event published and remove it from the pending index."""
        event_key = self._key(
            self.key_config.outbox_event,
            event_id=event_id,
        )
        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    await pipe.watch(event_key)
                    raw = await pipe.get(event_key)
                    if raw is None:
                        await pipe.unwatch()
                        return "missing", None
                    event = OutboxEventRecord.model_validate_json(raw)
                    if event.published_at is not None:
                        await pipe.unwatch()
                        return "already_published", event
                    updated = event.model_copy(
                        update={
                            "published_at": published_at,
                            "publish_attempts": event.publish_attempts + 1,
                        },
                    )
                    pipe.multi()
                    pipe.set(event_key, updated.model_dump_json())
                    pipe.srem(self.key_config.outbox_pending, event_id)
                    await pipe.execute()
                    return "published", updated
                except _watch_error():
                    continue

        raise RuntimeError(
            "Could not mark the outbox event after Redis contention.",
        )

    async def upsert_schedule(
        self,
        user_id: str,
        record: ScheduleRecord,
    ) -> str:
        """Persist a cron task record and register it in the user and global
        indexes."""
        key = self._key(
            self.key_config.schedule,
            user_id=user_id,
            schedule_id=record.id,
        )
        index_key = self._key(self.key_config.schedule_index, user_id=user_id)
        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(index_key, record.id)
        await self._client.sadd(
            self.key_config.schedule_global_index,
            f"{user_id}:{record.id}",
        )
        return record.id

    async def get_schedule(
        self,
        user_id: str,
        schedule_id: str,
    ) -> ScheduleRecord | None:
        """Fetch a single cron task record by id."""
        key = self._key(
            self.key_config.schedule,
            user_id=user_id,
            schedule_id=schedule_id,
        )
        raw = await self._client.get(key)
        if not raw:
            return None
        return ScheduleRecord.model_validate_json(raw)

    async def list_schedules(self, user_id: str) -> list[ScheduleRecord]:
        """Return all cron task records belonging to the given user."""
        index_key = self._key(
            self.key_config.schedule_index,
            user_id=user_id,
        )
        ids = await self._client.smembers(index_key)
        records = []
        for schedule_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.schedule,
                    user_id=user_id,
                    schedule_id=schedule_id,
                ),
            )
            if raw:
                records.append(ScheduleRecord.model_validate_json(raw))
        return records

    async def delete_schedule(self, user_id: str, schedule_id: str) -> bool:
        """Delete a cron task record, cascade-delete its execution sessions,
        and remove it from the user and global indexes."""
        key = self._key(
            self.key_config.schedule,
            user_id=user_id,
            schedule_id=schedule_id,
        )
        raw = await self._client.get(key)
        if not raw:
            return False

        record = ScheduleRecord.model_validate_json(raw)

        # Cascade: delete all sessions created by this schedule
        sessions = await self.list_sessions_by_schedule(user_id, schedule_id)
        for session in sessions:
            await self.delete_session(
                user_id,
                record.agent_id,
                session.id,
            )

        # Clean up the schedule session index key itself
        schedule_session_key = self._key(
            self.key_config.schedule_session_index,
            user_id=user_id,
            schedule_id=schedule_id,
        )
        await self._client.delete(schedule_session_key)

        # Delete the schedule record and its index entries
        index_key = self._key(self.key_config.schedule_index, user_id=user_id)
        await self._client.delete(key)
        await self._client.srem(index_key, schedule_id)
        await self._client.srem(
            self.key_config.schedule_global_index,
            f"{user_id}:{schedule_id}",
        )
        return True

    async def list_all_schedules(self) -> list[ScheduleRecord]:
        """Return every schedule record across all users.

        Reads the global schedule index (a Redis Set of ``user_id:schedule_id``
        pairs) and fetches each record individually.  Records whose keys have
        expired or been deleted externally are silently skipped.

        Returns:
            `list[ScheduleRecord]`: All schedule records in the store.
        """
        entries = await self._client.smembers(
            self.key_config.schedule_global_index,
        )
        records = []
        for entry in entries:
            user_id, schedule_id = entry.split(":", 1)
            raw = await self._client.get(
                self._key(
                    self.key_config.schedule,
                    user_id=user_id,
                    schedule_id=schedule_id,
                ),
            )
            if raw:
                records.append(ScheduleRecord.model_validate_json(raw))
        return records

    # ------------------------------------------------------------------
    # Channel persistence
    # ------------------------------------------------------------------

    async def upsert_channel(
        self,
        record: ChannelRecord,
        platform_bot_id: str,
    ) -> str:
        """Persist a channel record and refresh its indexes."""
        key = self._key(self.key_config.channel, channel_id=record.id)
        index_key = self._key(
            self.key_config.channel_index,
            user_id=record.user_id,
        )
        botid_key = self._key(
            self.key_config.channel_botid_index,
            platform_bot_id=platform_bot_id,
        )
        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(index_key, record.id)
        await self._client.sadd(self.key_config.channel_all_index, record.id)
        await self._set_with_ttl(botid_key, record.id)
        return record.id

    async def get_channel(
        self,
        channel_id: str,
    ) -> ChannelRecord | None:
        """Fetch a channel record by its global id."""
        raw = await self._client.get(
            self._key(self.key_config.channel, channel_id=channel_id),
        )
        if not raw:
            return None
        return ChannelRecord.model_validate_json(raw)

    async def list_channels(self, user_id: str) -> list[ChannelRecord]:
        """Return all channel records owned by the given user.

        Stale entries whose record key has expired are purged from the
        user index (self-healing).
        """
        index_key = self._key(self.key_config.channel_index, user_id=user_id)
        return await self._collect_channels(
            index_key,
            await self._client.smembers(index_key),
        )

    async def list_all_channels(self) -> list[ChannelRecord]:
        """Return every channel record across all users."""
        index_key = self.key_config.channel_all_index
        return await self._collect_channels(
            index_key,
            await self._client.smembers(index_key),
        )

    async def _collect_channels(
        self,
        index_key: str,
        ids: "set[str]",
    ) -> list[ChannelRecord]:
        """Load channel records for ``ids``, purging stale index entries."""
        records: list[ChannelRecord] = []
        stale: list[str] = []
        for channel_id in ids:
            raw = await self._client.get(
                self._key(self.key_config.channel, channel_id=channel_id),
            )
            if raw:
                records.append(ChannelRecord.model_validate_json(raw))
            else:
                stale.append(channel_id)
        if stale:
            await self._client.srem(index_key, *stale)
        return records

    async def delete_channel(
        self,
        channel_id: str,
        platform_bot_id: str,
    ) -> bool:
        """Delete a channel record and clean up all indexes."""
        key = self._key(self.key_config.channel, channel_id=channel_id)
        raw = await self._client.get(key)
        if not raw:
            return False
        record = ChannelRecord.model_validate_json(raw)

        await self._client.delete(key)
        await self._client.srem(
            self._key(
                self.key_config.channel_index,
                user_id=record.user_id,
            ),
            channel_id,
        )
        await self._client.srem(self.key_config.channel_all_index, channel_id)
        await self._client.delete(
            self._key(
                self.key_config.channel_botid_index,
                platform_bot_id=platform_bot_id,
            ),
        )
        return True

    async def get_channel_id_by_platform_bot_id(
        self,
        platform_bot_id: str,
    ) -> str | None:
        """Return the channel id bound to a platform bot, if any."""
        return await self._client.get(
            self._key(
                self.key_config.channel_botid_index,
                platform_bot_id=platform_bot_id,
            ),
        )

    # ------------------------------------------------------------------
    # Message persistence
    # ------------------------------------------------------------------

    def _message_key(self, user_id: str, session_id: str) -> str:
        """Return the Redis List key for a session's messages."""
        return self._key(
            self.key_config.messages,
            user_id=user_id,
            session_id=session_id,
        )

    async def upsert_message(
        self,
        user_id: str,
        session_id: str,
        msg: Msg,
    ) -> None:
        """Persist a message to the session's message list."""
        key = self._message_key(user_id, session_id)
        length = await self._client.llen(key)
        # A retried chat request can revisit an earlier user message after
        # its assistant reply has already been appended. Search by message
        # id rather than looking at the tail only, otherwise a true upsert
        # becomes a duplicate list entry and produces colliding UI keys.
        for index in range(length - 1, -1, -1):
            raw = await self._client.lindex(key, index)
            if raw and Msg.model_validate_json(raw).id == msg.id:
                await self._client.lset(key, index, msg.model_dump_json())
                await self._refresh_key_ttl(key)
                return
        await self._client.rpush(key, msg.model_dump_json())
        await self._refresh_key_ttl(key)

    async def get_message(
        self,
        user_id: str,
        session_id: str,
        message_id: str,
    ) -> Msg | None:
        """Fetch a single message by id from the session's message list."""
        key = self._message_key(user_id, session_id)
        length = await self._client.llen(key)
        for i in range(length - 1, -1, -1):
            raw = await self._client.lindex(key, i)
            if raw:
                msg = Msg.model_validate_json(raw)
                if msg.id == message_id:
                    return msg
        return None

    async def _find_message_index(
        self,
        key: str,
        message_id: str,
        chunk_size: int = 100,
    ) -> int | None:
        """Return the index of a message in the Redis list, or ``None``.

        Scans backwards from the tail (most recent) in chunks, since
        ``before`` cursors are typically near the end.

        Args:
            key (`str`): The Redis list key.
            message_id (`str`): The message ID to locate.
            chunk_size (`int`, optional): Number of entries fetched per
                round trip. Defaults to 100.

        Returns:
            `int | None`: Zero-based index, or ``None`` if not found.
        """
        end = await self._client.llen(key) - 1
        while end >= 0:
            start = max(end - chunk_size + 1, 0)
            raw_list = await self._client.lrange(key, start, end)
            for offset, raw in enumerate(reversed(raw_list)):
                if Msg.model_validate_json(raw).id == message_id:
                    return end - offset
            end = start - 1
        return None

    async def list_messages(
        self,
        user_id: str,
        session_id: str,
        limit: int = 50,
        before: str | None = None,
        **kwargs: Any,
    ) -> tuple[list[Msg], bool]:
        """Return the most recent messages with cursor-based pagination.

        Messages are returned in chronological order.

        Args:
            user_id (`str`): The owner user id.
            session_id (`str`): The session id.
            limit (`int`, optional): Maximum number of messages to
                return. Defaults to 50.
            before (`str | None`, optional): A message ID used as the
                cursor. When provided, returns messages created before
                this message. Omit to get the latest page.
            **kwargs: Reserved for backward compatibility. Passing
                ``offset`` will emit a ``DeprecationWarning`` and be
                ignored.

        Returns:
            `tuple[list[Msg], bool]`: A tuple of (messages in
            chronological order, has_more). ``has_more`` is ``True``
            when older messages exist before the returned page.
        """
        if "offset" in kwargs:
            warnings.warn(
                "The 'offset' parameter is deprecated and will be "
                "removed in a future version. Use 'before' for "
                "cursor-based pagination instead.",
                DeprecationWarning,
                stacklevel=2,
            )

        key = self._message_key(user_id, session_id)
        total = await self._client.llen(key)

        if total == 0:
            return [], False

        if before is None:
            end = total - 1
        else:
            idx = await self._find_message_index(key, before)
            if idx is None:
                return [], False
            end = idx - 1

        start = max(end - limit + 1, 0)
        if end < 0:
            return [], False

        raw_list = await self._client.lrange(key, start, end)
        has_more = start > 0
        return [Msg.model_validate_json(raw) for raw in raw_list], has_more

    # ------------------------------------------------------------------
    # Team persistence
    # ------------------------------------------------------------------

    async def upsert_team(
        self,
        user_id: str,
        record: TeamRecord,
    ) -> TeamRecord:
        """Persist a team record and register it in the user's team index.

        Args:
            user_id (`str`):
                The owner user id. Used to scope both the record key and
                the per-user team index.
            record (`TeamRecord`):
                The team record to persist. Its ``id`` is used as the
                primary key; an existing record with the same id is
                overwritten. ``updated_at`` is refreshed to ``datetime.now()``
                before writing.

        Returns:
            `TeamRecord`:
                The stored record (with refreshed ``updated_at``).
        """
        record.updated_at = datetime.now()
        key = self._key(
            self.key_config.team,
            user_id=user_id,
            team_id=record.id,
        )
        index_key = self._key(self.key_config.team_index, user_id=user_id)
        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(index_key, record.id)
        return record

    async def get_team(
        self,
        user_id: str,
        team_id: str,
    ) -> TeamRecord | None:
        """Fetch a single team record by id.

        Args:
            user_id (`str`):
                The owner user id.
            team_id (`str`):
                The team id to look up.

        Returns:
            `TeamRecord | None`:
                The record, or ``None`` if no record exists at the
                ``(user_id, team_id)`` key (e.g. expired or never created).
        """
        key = self._key(
            self.key_config.team,
            user_id=user_id,
            team_id=team_id,
        )
        raw = await self._client.get(key)
        if not raw:
            return None
        return TeamRecord.model_validate_json(raw)

    async def list_teams(self, user_id: str) -> list[TeamRecord]:
        """Return all team records belonging to the given user.

        Reads the per-user team index (a Redis Set of team ids) and fetches
        each record individually. Records whose keys have expired or been
        deleted externally are silently skipped.

        Args:
            user_id (`str`):
                The owner user id whose teams to list.

        Returns:
            `list[TeamRecord]`:
                All team records for the user, in arbitrary order (the
                index is a Set).
        """
        index_key = self._key(self.key_config.team_index, user_id=user_id)
        ids = await self._client.smembers(index_key)
        records: list[TeamRecord] = []
        for team_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.team,
                    user_id=user_id,
                    team_id=team_id,
                ),
            )
            if raw:
                records.append(TeamRecord.model_validate_json(raw))
        return records

    async def set_session_team_id(
        self,
        user_id: str,
        session_id: str,
        team_id: str | None,
    ) -> None:
        """Set or clear ``team_id`` on an existing session record.

        Bypasses :meth:`upsert_session` because that method does not
        allow writing ``team_id`` (which is a relation column the
        application normally only mutates via team operations).
        Idempotent: a no-op if the session does not exist or already
        holds the given value.

        Args:
            user_id (`str`):
                The owner user id.
            session_id (`str`):
                The session whose ``team_id`` should be updated.
            team_id (`str | None`):
                The new value. ``None`` detaches the session from any
                team (used by :meth:`delete_team` and by the team
                service when a session leaves a team).
        """
        key = self._key(
            self.key_config.session,
            user_id=user_id,
            session_id=session_id,
        )
        raw = await self._client.get(key)
        if not raw:
            return
        record = SessionRecord.model_validate_json(raw)
        if record.team_id == team_id:
            return
        record.team_id = team_id
        record.updated_at = datetime.now()
        await self._set_with_ttl(key, record.model_dump_json())

    async def delete_team(self, user_id: str, team_id: str) -> bool:
        """Delete a team record and cascade-clean its members by role.

        Cascade order (mirrors what SQL's ``ON DELETE CASCADE`` would do
        for the same set of foreign keys, but role-aware to honour the
        ``AgentInvite`` semantics — see :class:`TeamMember`):

        1. Materialise the member roster via
           :func:`ensure_team_members` (which migrates legacy
           ``member_ids``-only records on first read). For each entry:

           - ``role == "created"`` — the member was spawned by
             ``AgentCreate`` and lives only for this team. Delete it in
             full via :meth:`delete_agent`, which cascades that
             worker's session.
           - ``role == "invited"`` — the member is a pre-existing
             user-owned agent that was borrowed via ``AgentInvite``.
             Only remove the team-scoped session from the team owner's
             namespace via
             :meth:`delete_session`; the underlying
             :class:`AgentRecord` and its other sessions must survive.

        2. Clear ``team_id`` on the leader session (referenced by
           :attr:`TeamRecord.session_id`) — semantically equivalent to
           ``ON DELETE SET NULL`` for that direction of the relationship.
           Idempotent if the session has already been deleted (no-op).
        3. Delete the :class:`TeamRecord` key and remove it from the
           per-user team index.

        The cascade is best-effort: Redis has no cross-key transaction,
        so a process crash mid-cascade may leave residue. Each step is
        idempotent so retries are safe.

        Args:
            user_id (`str`):
                The owner user id.
            team_id (`str`):
                The id of the team to delete.

        Returns:
            `bool`:
                ``True`` if the team record existed and was deleted,
                ``False`` if no record was found at the
                ``(user_id, team_id)`` key.
        """
        # Local import to avoid a top-level cycle between _utils (which
        # imports TeamMember from _model) and _base (which imports the
        # abstract StorageBase from this module hierarchy).
        from ._utils import _ensure_team_members

        team = await self.get_team(user_id, team_id)
        if team is None:
            # Make sure the index is also clean if the record vanished
            # for any reason.
            index_key = self._key(self.key_config.team_index, user_id=user_id)
            await self._client.srem(index_key, team_id)
            return False

        # Role-aware member cleanup — see docstring above.
        members = await _ensure_team_members(self, user_id, team)
        for member in members:
            if member.role == "created":
                await self.delete_agent(member.owner_id, member.agent_id)
            else:  # invited
                await self.delete_session(
                    user_id,
                    member.agent_id,
                    member.session_id,
                )

        # Clear team_id on the leader session (idempotent)
        await self.set_session_team_id(user_id, team.session_id, None)

        # Delete the TeamRecord key + index entry
        key = self._key(
            self.key_config.team,
            user_id=user_id,
            team_id=team_id,
        )
        existed = await self._client.delete(key)
        index_key = self._key(self.key_config.team_index, user_id=user_id)
        await self._client.srem(index_key, team_id)
        return bool(existed)

    # ------------------------------------------------------------------
    # Knowledge base persistence
    # ------------------------------------------------------------------

    async def upsert_knowledge_base(
        self,
        user_id: str,
        record: KnowledgeBaseRecord,
    ) -> KnowledgeBaseRecord:
        """Persist a knowledge base record and register it in the user index.

        If a record with the same ``id`` already exists it is overwritten
        and ``updated_at`` is refreshed; ``created_at`` is preserved.

        Args:
            user_id (`str`):
                The owner user id.
            record (`KnowledgeBaseRecord`):
                The fully-populated record to store.

        Returns:
            `KnowledgeBaseRecord`:
                The stored record (with ``updated_at`` refreshed).
        """
        if record.user_id != user_id:
            raise ValueError(
                "record.user_id does not match the given user_id.",
            )

        key = self._key(
            self.key_config.knowledge_base,
            user_id=user_id,
            knowledge_base_id=record.id,
        )
        existing_raw = await self._client.get(key)
        if existing_raw:
            existing = KnowledgeBaseRecord.model_validate_json(existing_raw)
            record.created_at = existing.created_at
        record.updated_at = datetime.now()

        index_key = self._key(
            self.key_config.knowledge_base_index,
            user_id=user_id,
        )
        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(index_key, record.id)
        return record

    async def get_knowledge_base(
        self,
        user_id: str,
        knowledge_base_id: str,
    ) -> KnowledgeBaseRecord | None:
        """Fetch a single knowledge base record by id.

        Args:
            user_id (`str`):
                The owner user id.
            knowledge_base_id (`str`):
                The knowledge base id.

        Returns:
            `KnowledgeBaseRecord | None`:
                The record, or ``None`` if not found.
        """
        key = self._key(
            self.key_config.knowledge_base,
            user_id=user_id,
            knowledge_base_id=knowledge_base_id,
        )
        raw = await self._client.get(key)
        return KnowledgeBaseRecord.model_validate_json(raw) if raw else None

    async def list_knowledge_bases(
        self,
        user_id: str,
    ) -> list[KnowledgeBaseRecord]:
        """List all knowledge base records belonging to the given user.

        Reads the per-user knowledge base index Set to obtain all ids,
        then fetches each record individually. Records whose keys have
        expired or been deleted externally are silently skipped.

        Args:
            user_id (`str`):
                The owner user id.

        Returns:
            `list[KnowledgeBaseRecord]`:
                All knowledge base records for the user.
        """
        index_key = self._key(
            self.key_config.knowledge_base_index,
            user_id=user_id,
        )
        ids = await self._client.smembers(index_key)
        records: list[KnowledgeBaseRecord] = []
        for kb_id in ids:
            raw = await self._client.get(
                self._key(
                    self.key_config.knowledge_base,
                    user_id=user_id,
                    knowledge_base_id=kb_id,
                ),
            )
            if raw:
                records.append(
                    KnowledgeBaseRecord.model_validate_json(raw),
                )
        return records

    async def delete_knowledge_base(
        self,
        user_id: str,
        knowledge_base_id: str,
    ) -> bool:
        """Delete a knowledge base record and remove it from the index.

        Cascades the per-knowledge-base document index: every
        :class:`KnowledgeDocumentRecord` indexed under the KB is
        removed from storage so no orphan documents survive the KB
        deletion.  Cleanup of the underlying vector store collection
        and blob payloads remains the caller's responsibility (the
        manager + the blob store, respectively).

        Args:
            user_id (`str`):
                The owner user id.
            knowledge_base_id (`str`):
                The id of the record to delete.

        Returns:
            `bool`:
                ``True`` if the record existed and was deleted,
                ``False`` if not found.
        """
        # Cascade: drop every document record so the sweeper does not
        # later try to redispatch leases for a KB that no longer exists.
        documents = await self.list_knowledge_documents(
            user_id,
            knowledge_base_id,
        )
        for document in documents:
            await self.delete_knowledge_document(
                user_id,
                knowledge_base_id,
                document.id,
            )

        key = self._key(
            self.key_config.knowledge_base,
            user_id=user_id,
            knowledge_base_id=knowledge_base_id,
        )
        index_key = self._key(
            self.key_config.knowledge_base_index,
            user_id=user_id,
        )
        deleted = await self._client.delete(key)
        await self._client.srem(index_key, knowledge_base_id)
        return deleted > 0

    # ------------------------------------------------------------------
    # Knowledge document persistence
    # ------------------------------------------------------------------

    def _document_key(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
    ) -> str:
        """Format the Redis key for one document record."""
        return self._key(
            self.key_config.knowledge_document,
            user_id=user_id,
            knowledge_base_id=knowledge_base_id,
            document_id=document_id,
        )

    def _document_index_key(
        self,
        user_id: str,
        knowledge_base_id: str,
    ) -> str:
        """Format the per-KB document index Set key."""
        return self._key(
            self.key_config.knowledge_document_index,
            user_id=user_id,
            knowledge_base_id=knowledge_base_id,
        )

    def _document_global_token(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
    ) -> str:
        """Encode (user_id, kb_id, doc_id) for the global sweeper index."""
        return f"{user_id}:{knowledge_base_id}:{document_id}"

    async def upsert_knowledge_document(
        self,
        user_id: str,
        record: KnowledgeDocumentRecord,
    ) -> KnowledgeDocumentRecord:
        """Persist a document record and update its indexes.

        If a record with the same ``id`` already exists it is
        overwritten and ``updated_at`` refreshed; ``created_at`` is
        preserved.

        Args:
            user_id (`str`):
                The owner user id.  Must match ``record.user_id``.
            record (`KnowledgeDocumentRecord`):
                The fully-populated record to persist.

        Returns:
            `KnowledgeDocumentRecord`:
                The stored record (with ``updated_at`` refreshed).
        """
        if record.user_id != user_id:
            raise ValueError(
                "record.user_id does not match the given user_id.",
            )

        key = self._document_key(
            user_id,
            record.knowledge_base_id,
            record.id,
        )
        existing_raw = await self._client.get(key)
        if existing_raw:
            existing = KnowledgeDocumentRecord.model_validate_json(
                existing_raw,
            )
            record.created_at = existing.created_at
        record.updated_at = datetime.now()

        await self._set_with_ttl(key, record.model_dump_json())
        await self._client.sadd(
            self._document_index_key(user_id, record.knowledge_base_id),
            record.id,
        )
        await self._client.sadd(
            self.key_config.knowledge_document_global_index,
            self._document_global_token(
                user_id,
                record.knowledge_base_id,
                record.id,
            ),
        )
        return record

    async def get_knowledge_document(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
    ) -> KnowledgeDocumentRecord | None:
        """Fetch a single knowledge document record by id."""
        raw = await self._client.get(
            self._document_key(user_id, knowledge_base_id, document_id),
        )
        return (
            KnowledgeDocumentRecord.model_validate_json(raw) if raw else None
        )

    async def list_knowledge_documents(
        self,
        user_id: str,
        knowledge_base_id: str,
    ) -> list[KnowledgeDocumentRecord]:
        """List all documents in a knowledge base.

        Reads the per-KB document index Set and fetches each record.
        Records whose keys have expired or been deleted externally are
        silently skipped.
        """
        ids = await self._client.smembers(
            self._document_index_key(user_id, knowledge_base_id),
        )
        records: list[KnowledgeDocumentRecord] = []
        for document_id in ids:
            raw = await self._client.get(
                self._document_key(user_id, knowledge_base_id, document_id),
            )
            if raw:
                records.append(
                    KnowledgeDocumentRecord.model_validate_json(raw),
                )
        return records

    async def delete_knowledge_document(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
    ) -> bool:
        """Delete a document record and remove it from the indexes."""
        key = self._document_key(user_id, knowledge_base_id, document_id)
        deleted = await self._client.delete(key)
        await self._client.srem(
            self._document_index_key(user_id, knowledge_base_id),
            document_id,
        )
        await self._client.srem(
            self.key_config.knowledge_document_global_index,
            self._document_global_token(
                user_id,
                knowledge_base_id,
                document_id,
            ),
        )
        return deleted > 0

    async def update_knowledge_document_status(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
        status: KnowledgeDocumentStatus,
        error: str | None = None,
        chunk_count: int | None = None,
    ) -> None:
        """Update only the status-related fields of a document record.

        Reads the record, mutates the status fields in memory, and
        writes it back.  Not atomic across multiple writers — relies
        on the indexing worker holding the lease, which serialises
        status transitions for a single document.
        """
        key = self._document_key(user_id, knowledge_base_id, document_id)
        raw = await self._client.get(key)
        if not raw:
            return
        record = KnowledgeDocumentRecord.model_validate_json(raw)
        record.status = status
        if error is not None:
            record.data.error = error
        if chunk_count is not None:
            record.data.chunk_count = chunk_count
        record.updated_at = datetime.now()
        await self._set_with_ttl(key, record.model_dump_json())

    async def acquire_knowledge_document_lease(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
        processing_node: str,
        lease_ttl: timedelta,
        now: datetime | None = None,
    ) -> bool:
        """Compare-and-swap acquisition of the processing lease.

        Implementation is a read-modify-write under a per-document
        ``WATCH`` so two workers racing on the same document cannot
        both win.  Redis ``WATCH`` aborts the transaction if the key
        changes between WATCH and EXEC; we retry a few times on
        ``WatchError`` and otherwise give up (treating the contention
        as "someone else already holds the lease").
        """
        now = now or datetime.now()
        new_deadline = now + lease_ttl

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    key = self._document_key(
                        user_id,
                        knowledge_base_id,
                        document_id,
                    )
                    await pipe.watch(key)
                    raw = await pipe.get(key)
                    if not raw:
                        await pipe.unwatch()
                        return False
                    record = KnowledgeDocumentRecord.model_validate_json(raw)
                    holder = record.processing_node
                    deadline = record.lease_expires_at
                    if (
                        holder is not None
                        and deadline is not None
                        and deadline > now
                    ):
                        await pipe.unwatch()
                        return False
                    record.processing_node = processing_node
                    record.lease_expires_at = new_deadline
                    record.updated_at = now
                    pipe.multi()
                    pipe.set(key, record.model_dump_json())
                    if self.key_ttl is not None:
                        pipe.expire(key, self.key_ttl)
                    await pipe.execute()
                    return True
                except _watch_error():
                    # Another writer touched the key between WATCH and
                    # EXEC; loop and re-read.
                    continue
            return False

    async def renew_knowledge_document_lease(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
        processing_node: str,
        lease_ttl: timedelta,
        now: datetime | None = None,
    ) -> bool:
        """Extend the lease this worker already holds."""
        now = now or datetime.now()
        new_deadline = now + lease_ttl

        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    key = self._document_key(
                        user_id,
                        knowledge_base_id,
                        document_id,
                    )
                    await pipe.watch(key)
                    raw = await pipe.get(key)
                    if not raw:
                        await pipe.unwatch()
                        return False
                    record = KnowledgeDocumentRecord.model_validate_json(raw)
                    if record.processing_node != processing_node:
                        await pipe.unwatch()
                        return False
                    record.lease_expires_at = new_deadline
                    record.updated_at = now
                    pipe.multi()
                    pipe.set(key, record.model_dump_json())
                    if self.key_ttl is not None:
                        pipe.expire(key, self.key_ttl)
                    await pipe.execute()
                    return True
                except _watch_error():
                    continue
            return False

    async def release_knowledge_document_lease(
        self,
        user_id: str,
        knowledge_base_id: str,
        document_id: str,
        processing_node: str,
    ) -> None:
        """Release the lease only if this worker still owns it."""
        async with self._client.pipeline(transaction=True) as pipe:
            for _ in range(3):
                try:
                    key = self._document_key(
                        user_id,
                        knowledge_base_id,
                        document_id,
                    )
                    await pipe.watch(key)
                    raw = await pipe.get(key)
                    if not raw:
                        await pipe.unwatch()
                        return
                    record = KnowledgeDocumentRecord.model_validate_json(raw)
                    if record.processing_node != processing_node:
                        await pipe.unwatch()
                        return
                    record.processing_node = None
                    record.lease_expires_at = None
                    record.updated_at = datetime.now()
                    pipe.multi()
                    pipe.set(key, record.model_dump_json())
                    if self.key_ttl is not None:
                        pipe.expire(key, self.key_ttl)
                    await pipe.execute()
                    return
                except _watch_error():
                    continue

    async def list_knowledge_documents_with_expired_lease(
        self,
        now: datetime | None = None,
    ) -> list[KnowledgeDocumentRecord]:
        """Return non-terminal documents whose lease has expired.

        Reads the global document index and filters in-memory — there
        is no Redis-side filter primitive that knows about our nested
        ``data.lease_expires_at`` field.  For production deployments
        with very large document counts a secondary index would pay
        off, but for the v1 workload the global scan is acceptable
        because the sweep runs on a slow cadence (minutes) and only
        cares about the small subset of non-terminal documents.
        """
        now = now or datetime.now()
        terminal = {"ready", "error"}
        tokens = await self._client.smembers(
            self.key_config.knowledge_document_global_index,
        )
        records: list[KnowledgeDocumentRecord] = []
        for token in tokens:
            try:
                user_id, kb_id, document_id = token.split(":", 2)
            except ValueError:
                continue
            raw = await self._client.get(
                self._document_key(user_id, kb_id, document_id),
            )
            if not raw:
                continue
            record = KnowledgeDocumentRecord.model_validate_json(raw)
            if record.status in terminal:
                continue
            if record.processing_node is None:
                continue
            if (
                record.lease_expires_at is not None
                and record.lease_expires_at < now
            ):
                records.append(record)
        return records

    async def list_knowledge_documents_pending_since(
        self,
        threshold: datetime,
    ) -> list[KnowledgeDocumentRecord]:
        """Return documents stuck in ``pending`` since before ``threshold``."""
        tokens = await self._client.smembers(
            self.key_config.knowledge_document_global_index,
        )
        records: list[KnowledgeDocumentRecord] = []
        for token in tokens:
            try:
                user_id, kb_id, document_id = token.split(":", 2)
            except ValueError:
                continue
            raw = await self._client.get(
                self._document_key(user_id, kb_id, document_id),
            )
            if not raw:
                continue
            record = KnowledgeDocumentRecord.model_validate_json(raw)
            if record.status != "pending":
                continue
            if record.created_at < threshold:
                records.append(record)
        return records
