# -*- coding: utf-8 -*-
"""JWKS-backed JWT verification with bounded caching and key refresh."""
import asyncio
import time
from collections.abc import Awaitable, Callable, Mapping, Sequence
from urllib.parse import urlparse
from typing import Any

import httpx

from ._jwt import PyJWTVerifier


JWKSFetcher = Callable[[str], Awaitable[Mapping[str, object]]]


async def _fetch_jwks(url: str) -> Mapping[str, object]:
    """Fetch one JWKS document over the configured HTTPS endpoint."""
    async with httpx.AsyncClient(timeout=5.0) as client:
        response = await client.get(url)
        response.raise_for_status()
        document = response.json()
    if not isinstance(document, Mapping):
        raise ValueError("JWKS endpoint returned an invalid document.")
    return document


class JWKSVerifier:
    """Verify JWTs using issuer-published keys with ``kid`` refresh.

    The verifier caches a validated key set for a short period. An unknown
    ``kid`` causes exactly one forced refresh, which handles normal key
    rotation without refreshing on every request. The injected fetcher keeps
    tests deterministic and can be replaced by a production HTTP client.
    """

    def __init__(
        self,
        jwks_url: str,
        *,
        issuer: str,
        audience: str | Sequence[str],
        algorithms: Sequence[str] = ("RS256",),
        cache_ttl_secs: int | float = 300,
        fetcher: JWKSFetcher | None = None,
        require_customer_id: bool = True,
    ) -> None:
        """Bind a JWKS endpoint and the claims accepted by this service."""
        parsed_url = urlparse(jwks_url)
        if parsed_url.scheme != "https" or not parsed_url.netloc:
            raise ValueError("JWKS URL must be an absolute HTTPS URL.")
        if cache_ttl_secs <= 0:
            raise ValueError("JWKS cache TTL must be positive.")
        self._jwks_url = jwks_url
        self._issuer = issuer
        self._audience = audience
        self._algorithms = tuple(algorithms)
        self._cache_ttl_secs = cache_ttl_secs
        self._fetcher = fetcher or _fetch_jwks
        self._require_customer_id = require_customer_id
        self._keys: dict[tuple[str, str], Any] = {}
        self._expires_at = 0.0
        self._refresh_lock = asyncio.Lock()

    async def _load_keys(self, *, force: bool = False) -> dict[tuple[str, str], Any]:
        """Load and cache usable signing keys, coalescing concurrent refreshes."""
        now = time.monotonic()
        if not force and self._keys and now < self._expires_at:
            return self._keys

        async with self._refresh_lock:
            now = time.monotonic()
            if not force and self._keys and now < self._expires_at:
                return self._keys
            document = await self._fetcher(self._jwks_url)
            keys = self._parse_keys(document)
            self._keys = keys
            self._expires_at = time.monotonic() + self._cache_ttl_secs
            return keys

    def _parse_keys(
        self,
        document: Mapping[str, object],
    ) -> dict[tuple[str, str], Any]:
        """Convert only explicit signature keys into a lookup table."""
        import jwt

        raw_keys = document.get("keys")
        if not isinstance(raw_keys, list):
            raise ValueError("JWKS document has no valid keys list.")

        parsed: dict[tuple[str, str], Any] = {}
        for raw_key in raw_keys:
            if not isinstance(raw_key, dict):
                continue
            kid = raw_key.get("kid")
            algorithm = raw_key.get("alg")
            use = raw_key.get("use")
            if (
                not isinstance(kid, str)
                or not kid.strip()
                or not isinstance(algorithm, str)
                or algorithm not in self._algorithms
                or (use is not None and use != "sig")
            ):
                continue
            lookup_key = (kid, algorithm)
            if lookup_key in parsed:
                raise ValueError("JWKS contains duplicate signing key ids.")
            try:
                parsed[lookup_key] = jwt.PyJWK.from_dict(raw_key).key
            except jwt.PyJWTError:
                continue

        if not parsed:
            raise ValueError("JWKS contains no usable signing keys.")
        return parsed

    async def __call__(self, token: str) -> dict[str, object]:
        """Select a key by untrusted header metadata, then verify fully."""
        try:
            import jwt

            header = jwt.get_unverified_header(token)
        except Exception as exc:  # pylint: disable=broad-except
            raise ValueError("JWT header is invalid.") from exc

        kid = header.get("kid")
        algorithm = header.get("alg")
        if (
            not isinstance(kid, str)
            or not kid.strip()
            or not isinstance(algorithm, str)
            or algorithm not in self._algorithms
        ):
            raise ValueError("JWT signing metadata is not accepted.")

        keys = await self._load_keys()
        key = keys.get((kid, algorithm))
        if key is None:
            # A new kid may have appeared before the normal cache TTL elapsed.
            keys = await self._load_keys(force=True)
            key = keys.get((kid, algorithm))
        if key is None:
            raise ValueError("JWT signing key was not found.")

        return await PyJWTVerifier(
            key,
            issuer=self._issuer,
            audience=self._audience,
            algorithms=self._algorithms,
            key_id=kid,
            require_customer_id=self._require_customer_id,
        )(token)
