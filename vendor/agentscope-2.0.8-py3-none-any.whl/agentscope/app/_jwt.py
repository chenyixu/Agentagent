# -*- coding: utf-8 -*-
"""JWT verification adapter used by the application identity boundary."""
from collections.abc import Sequence
from typing import Any

from ._types import JWTClaimsVerifier


class PyJWTVerifier:
    """Verify a JWT with an explicitly configured public key and claims.

    The key is intentionally supplied by the application. This first adapter
    models a fixed-key deployment; a JWKS/key-rotation adapter can implement
    the same ``JWTClaimsVerifier`` contract later.
    """

    def __init__(
        self,
        key: Any,
        *,
        issuer: str,
        audience: str | Sequence[str],
        algorithms: Sequence[str] = ("RS256",),
        key_id: str | None = None,
        leeway: int | float = 0,
        require_customer_id: bool = True,
    ) -> None:
        """Bind a key and the claims that this service accepts."""
        configured_algorithms = tuple(algorithms)
        if not configured_algorithms or any(
            algorithm.lower() == "none"
            for algorithm in configured_algorithms
        ):
            raise ValueError("At least one non-none JWT algorithm is required.")
        if not issuer.strip():
            raise ValueError("JWT issuer must not be empty.")
        if isinstance(audience, str) and not audience.strip():
            raise ValueError("JWT audience must not be empty.")
        self._key = key
        self._issuer = issuer
        self._audience = audience
        self._algorithms = configured_algorithms
        self._key_id = key_id
        self._leeway = leeway
        self._require_customer_id = require_customer_id

    async def __call__(self, token: str) -> dict[str, object]:
        """Verify one token and return only verified claims."""
        try:
            import jwt

            if self._key_id is not None:
                header = jwt.get_unverified_header(token)
                if header.get("kid") != self._key_id:
                    raise ValueError("JWT key id does not match.")

            claims: Any = jwt.decode(
                token,
                self._key,
                algorithms=list(self._algorithms),
                issuer=self._issuer,
                audience=self._audience,
                leeway=self._leeway,
                options={
                    "require": [
                        "sub",
                        "tenant_id",
                        *(
                            ["customer_id"]
                            if self._require_customer_id
                            else []
                        ),
                        "exp",
                    ],
                },
            )
        except ValueError:
            raise
        except Exception as exc:  # pylint: disable=broad-except
            # Keep cryptographic and claim details out of the API response.
            raise ValueError("JWT verification failed.") from exc

        if not isinstance(claims, dict):
            raise ValueError("JWT verification returned invalid claims.")
        for name in ("sub", "tenant_id"):
            value = claims.get(name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError("JWT verification returned invalid claims.")
        customer_id = claims.get("customer_id")
        if customer_id is not None and (
            not isinstance(customer_id, str) or not customer_id.strip()
        ):
            raise ValueError("JWT verification returned invalid claims.")
        if self._require_customer_id and customer_id is None:
            raise ValueError("JWT verification returned invalid claims.")
        return claims
