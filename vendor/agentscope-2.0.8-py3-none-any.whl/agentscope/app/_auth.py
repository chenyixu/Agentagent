# -*- coding: utf-8 -*-
"""Authentication adapters for application-provided identity verifiers."""
from collections.abc import Collection, Mapping

from fastapi import HTTPException, Request, status

from ._types import JWTClaimsVerifier, Principal


def _unauthorized() -> HTTPException:
    """Return a generic bearer authentication failure."""
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or missing bearer token.",
        headers={"WWW-Authenticate": "Bearer"},
    )


def _required_text(claims: Mapping[str, object], name: str) -> str:
    """Read one required non-empty text claim without coercion."""
    value = claims.get(name)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Missing or invalid claim: {name}")
    return value


def _optional_text(claims: Mapping[str, object], name: str) -> str | None:
    """Read an optional text claim without coercion."""
    value = claims.get(name)
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Invalid claim: {name}")
    return value


def _roles(claims: Mapping[str, object]) -> frozenset[str]:
    """Normalize a small, explicit roles claim."""
    value = claims.get("roles")
    if value is None:
        return frozenset()
    if isinstance(value, str):
        values = value.split()
    elif isinstance(value, (list, tuple, set, frozenset)):
        values = list(value)
    else:
        raise ValueError("Invalid claim: roles")
    if not all(isinstance(item, str) and item.strip() for item in values):
        raise ValueError("Invalid claim: roles")
    return frozenset(values)


class BearerPrincipalProvider:
    """Map verifier-approved bearer claims to an immutable ``Principal``.

    This adapter intentionally does not decode or verify JWTs. The injected
    ``verifier`` owns signature, issuer, audience, time, and key-rotation
    checks. Raw tokens stay inside this adapter and are never returned to the
    application or AgentScope.
    """

    def __init__(
        self,
        verifier: JWTClaimsVerifier,
        *,
        roles_without_customer_id: Collection[str] = ("staff",),
    ) -> None:
        """Bind an application-owned cryptographic/token verifier."""
        self._verifier = verifier
        self._roles_without_customer_id = frozenset(roles_without_customer_id)

    async def __call__(self, request: Request) -> Principal:
        """Authenticate one request and return its trusted principal."""
        authorization = request.headers.get("authorization")
        parts = authorization.split() if authorization else []
        if len(parts) != 2 or parts[0].lower() != "bearer":
            raise _unauthorized()

        try:
            claims = await self._verifier(parts[1])
        except Exception as exc:  # pylint: disable=broad-except
            # Do not expose verifier details or the raw token to callers.
            raise _unauthorized() from exc

        if not isinstance(claims, Mapping):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Identity verifier returned invalid claims.",
            )

        try:
            roles = _roles(claims)
            customer_id = _optional_text(claims, "customer_id")
            if customer_id is None and not roles.intersection(
                self._roles_without_customer_id,
            ):
                raise ValueError("Customer identity is required for this role.")
            return Principal(
                user_id=_required_text(claims, "sub"),
                tenant_id=_required_text(claims, "tenant_id"),
                customer_id=customer_id,
                roles=roles,
            )
        except (TypeError, ValueError):
            raise _unauthorized() from None
