# -*- coding: utf-8 -*-
"""Structured worker-to-leader task reports."""
import json
from typing import Any, Literal

from pydantic import Field

from ._team_say import TeamSay
from ._team_tool_base import _TeamToolBase, _TeamToolError
from ..storage._utils import _ensure_team_members, _resolve_team_leader
from ...message import TextBlock, ToolResultState
from ...tool import ParamsBase, ToolChunk


class _TeamReportParams(ParamsBase):
    """The stable, model-visible part of a worker result."""

    task_id: str = Field(
        min_length=1,
        description=(
            "The server-assigned id from the current team task envelope. "
            "Do not invent or reuse another task id."
        ),
    )
    status: Literal["succeeded", "not_found", "failed", "timed_out"] = Field(
        description=(
            "The controlled result status. Use failed or timed_out when "
            "the task did not produce a reliable successful result."
        ),
    )
    result: dict[str, Any] = Field(
        default_factory=dict,
        description="Structured business result; never include scope secrets.",
    )
    error_code: str | None = Field(
        default=None,
        description="A short controlled error code when status is not success.",
    )


class TeamReport(_TeamToolBase):
    """Validate and deliver a worker's structured result to its leader.

    The task id is checked against the server-persisted team roster before
    the message is delivered.  This keeps a worker from claiming another
    worker's task and gives the Coordinator an unambiguous envelope to
    validate before aggregating results.
    """

    name: str = "TeamReport"
    description: str = (
        "Report the current task's structured result to the team leader. "
        "Use this as the final action of a worker turn."
    )
    input_schema: dict = _TeamReportParams.model_json_schema()
    is_concurrency_safe: bool = True
    is_read_only: bool = True

    async def __call__(
        self,
        task_id: str,
        status: Literal["succeeded", "not_found", "failed", "timed_out"],
        result: dict[str, Any] | None = None,
        error_code: str | None = None,
    ) -> ToolChunk:
        """Validate the assignment, then route one JSON report to leader."""
        try:
            team = await self._require_team()
            members = await _ensure_team_members(
                self._storage,
                self._user_id,
                team,
            )
            own_member = next(
                (
                    member
                    for member in members
                    if member.session_id == self._session_id
                ),
                None,
            )
            if own_member is None or own_member.task_id is None:
                raise _TeamToolError(
                    "this worker has no server-assigned task to report.",
                )
            if task_id != own_member.task_id:
                raise _TeamToolError(
                    "task_id does not match this worker's assignment.",
                )

            leader = await _resolve_team_leader(
                self._storage,
                self._user_id,
                team,
            )
            if leader is None:
                raise _TeamToolError(
                    "the team leader record is unavailable.",
                )

            payload = {
                "task_id": own_member.task_id,
                "task_type": own_member.task_type,
                "status": status,
                "result": result or {},
                "error_code": error_code,
            }
            return await TeamSay(
                storage=self._storage,
                message_bus=self._message_bus,
                workspace_manager=self._workspace_manager,
                user_id=self._user_id,
                session_id=self._session_id,
                agent_id=self._agent_id,
                role="worker",
            )(
                content=json.dumps(payload, ensure_ascii=False),
                to=leader.name,
            )
        except Exception as exc:  # pylint: disable=broad-except
            return ToolChunk(
                content=[TextBlock(text=f"TeamReport failed: {exc}")],
                state=ToolResultState.ERROR,
            )
