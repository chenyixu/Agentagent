# -*- coding: utf-8 -*-
"""Session router — create, list, update, delete, stream, and get messages."""
import asyncio
import json
from typing import Annotated, AsyncGenerator

from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from fastapi.responses import StreamingResponse

from ..._utils._common import _generate_id
from ..access import ResourceKind
from ..deps import (
    get_chat_service,
    get_current_principal_if_configured,
    get_current_user_id,
    get_message_bus,
    get_resource_access_service,
    get_session_scope_authorizer,
    get_session_service,
    get_storage,
    get_workspace_manager,
)
from ._schema import (
    CreateSessionRequest,
    CreateSessionResponse,
    InterruptSessionResponse,
    ListMessagesResponse,
    ListSessionsResponse,
    SessionStatusResponse,
    SessionView,
    TeamDetailResponse,
    TeamMemberView,
    UpdateSessionRequest,
)
from ..message_bus import MessageBus, MessageBusKeys
from .._service import (
    AgentView,
    ResourceAccessService,
    ChatService,
    SessionService,
    SessionStatus,
    SessionProjection,
    SubagentHitlProjector,
)
from .._types import Principal, SessionScopeAuthorizer
from ..storage import (
    ChatModelConfig,
    SessionKnowledgeConfig,
    TTSModelConfig,
    SessionConfig,
    SessionNaming,
    SessionRecord,
    StorageBase,
    TeamRecord,
)
from ...message import ToolCallState
from ...state import ToolContext
from ..storage._utils import _ensure_team_members, _resolve_team_leader
from ...event import CustomEvent
from ..workspace_manager import WorkspaceManagerBase


async def _build_team_detail(
    storage: StorageBase,
    access: ResourceAccessService,
    user_id: str,
    team: TeamRecord,
) -> TeamDetailResponse:
    """Resolve a team's leader agent + member agents into a
    :class:`TeamDetailResponse` for the session list endpoint.

    Args:
        storage (`StorageBase`):
            Application storage. Used to look up the leader session,
            each member agent, and each member's session.
        access (`ResourceAccessService`):
            Resolves roster agents against the viewer's current grants.
        user_id (`str`):
            The owner user id.
        team (`TeamRecord`):
            The team to resolve. Caller has already loaded it.

    Returns:
        `TeamDetailResponse`:
            The team plus its resolved leader and member agents (each
            member paired with its session id when available).
    """
    leader_agent: AgentView | None = None
    leader = await _resolve_team_leader(storage, user_id, team)
    if leader is not None:
        leader_agent = AgentView.model_validate(
            {
                **leader.agent.model_dump(),
                "editable": leader.agent.user_id == user_id,
            },
        )

    members: list[TeamMemberView] = []
    for member in await _ensure_team_members(storage, user_id, team):
        agent = await access.try_resolve_agent(user_id, member.agent_id)
        if agent is None or agent.user_id != member.owner_id:
            continue
        # Use the member's team-scoped session id directly; an invited
        # agent has multiple sessions and only ``member.session_id``
        # belongs to this team. A member whose owner is not the current
        # user was invited from another user's pool — read-only here.
        members.append(
            TeamMemberView(
                agent=AgentView.model_validate(
                    {
                        **agent.model_dump(),
                        "editable": member.owner_id == user_id,
                    },
                ),
                session_id=member.session_id,
            ),
        )

    return TeamDetailResponse(
        team=team,
        leader_agent=leader_agent,
        members=members,
    )


session_router = APIRouter(
    prefix="/sessions",
    tags=["sessions"],
    responses={404: {"description": "Not found"}},
)


async def _ensure_credential_exists(
    access: ResourceAccessService,
    user_id: str,
    config: ChatModelConfig | TTSModelConfig | None,
) -> None:
    """Validate that the credential referenced by ``config`` is visible to
    the given user (own or shared). No-op when ``config`` is ``None``.

    Args:
        access (`ResourceAccessService`): Injected access service.
        user_id (`str`): The authenticated user ID.
        config (`ChatModelConfig | TTSModelConfig | None`): Model config to
            validate. Pass ``None`` to skip the check.

    Raises:
        `HTTPException`: 404 if the credential does not exist or is not
            visible to the user.
    """
    if config is None:
        return
    # ``get_resource`` raises 404 when the credential is neither owned
    # nor shared to the viewer — exactly the semantics we want.
    await access.get_resource(
        user_id,
        ResourceKind.CREDENTIAL,
        config.credential_id,
    )


async def _ensure_knowledge_bases_exist(
    access: ResourceAccessService,
    user_id: str,
    config: SessionKnowledgeConfig | None,
) -> None:
    """Validate every KB id in ``config`` is visible to the given user.

    No-op when ``config`` is ``None`` or its ``knowledge_base_ids``
    list is empty.

    Args:
        access (`ResourceAccessService`): Injected access service.
        user_id (`str`): The authenticated user ID.
        config (`SessionKnowledgeConfig | None`):
            Knowledge config to validate.  Pass ``None`` to skip.

    Raises:
        `HTTPException`: 404 if any KB id is not visible to the user.
    """
    if config is None or not config.knowledge_base_ids:
        return
    for kb_id in config.knowledge_base_ids:
        await access.get_resource(
            user_id,
            ResourceKind.KNOWLEDGE_BASE,
            kb_id,
        )


def _session_matches_principal(
    session: SessionRecord,
    principal: Principal | None,
) -> bool:
    """Check a Session's immutable business scope against the caller.

    ``None`` means development header mode, where the legacy user-only
    behavior remains available. Once a production principal exists, an old
    unscoped record also fails closed because neither scope can be inferred.
    """
    if principal is None:
        return True
    return (
        principal.customer_id is not None
        and session.tenant_id == principal.tenant_id
        and session.customer_id == principal.customer_id
    )


async def _require_session_scope(
    session: SessionRecord,
    principal: Principal | None,
    authorizer: SessionScopeAuthorizer | None = None,
) -> None:
    """Hide a Session whose tenant/customer scope is not accessible."""
    accessible = _session_matches_principal(session, principal)
    # A staff principal may not carry ``customer_id``.  The application
    # callback can resolve its assigned customer from the server-side
    # identity directory, but only after the tenant boundary is matched.
    if (
        not accessible
        and principal is not None
        and callable(authorizer)
        and principal.tenant_id == session.tenant_id
        and "staff" in principal.roles
        and principal.customer_id is None
    ):
        accessible = True
    # Direct Python callers in tests/integrations do not receive FastAPI's
    # dependency value; they see the ``Depends`` marker as the default.  Only
    # invoke an actual callback, while keeping the framework-injected path
    # fail-closed when the configured callback raises.
    if accessible and principal is not None and callable(authorizer):
        try:
            accessible = await authorizer(principal, session)
        except Exception:  # pylint: disable=broad-except
            accessible = False
    if not accessible:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session.id}' not found.",
        )


@session_router.get(
    "/",
    response_model=ListSessionsResponse,
    summary="List sessions for an agent",
)
async def list_sessions(
    agent_id: str = Query(description="Filter sessions by agent ID."),
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    access: ResourceAccessService = Depends(get_resource_access_service),
    message_bus: MessageBus = Depends(get_message_bus),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
    session_scope_authorizer: SessionScopeAuthorizer | None = Depends(
        get_session_scope_authorizer,
    ),
) -> ListSessionsResponse:
    """Return all sessions for an agent as enriched
    :class:`SessionView` entries.

    Each entry bundles what the chat UI needs to render without
    follow-up requests: the session record, its status, and — when
    the session participates in a team — the resolved team detail
    (leader agent + member agents with their session ids).

    The record arrives trimmed: ``state.context``, ``state.summary``
    and ``state.tool_context`` are cleared, since they hold the model's
    conversation and every file it has read. Fetch a session's messages
    from ``GET /sessions/{id}/messages`` instead.

    Args:
        agent_id (`str`):
            Agent whose sessions to list. May be an agent shared to
            the viewer through :class:`ResourceAccessPolicyBase`;
            the returned sessions are still the viewer's own.
        user_id (`str`):
            Injected authenticated user ID.
        storage (`StorageBase`):
            Injected storage backend.
        access (`ResourceAccessService`):
            Injected resource access service; used to validate that
            the target agent is visible to the viewer.
        message_bus (`MessageBus`):
            Injected message bus (used for ``session_is_running``).

    Returns:
        `ListSessionsResponse`:
            Enriched session views and their count.

    Raises:
        `HTTPException`: 404 if the agent is not visible to the caller.
    """
    # Verify visibility (own or shared) — raises 404 otherwise. Sessions
    # themselves are always looked up under ``user_id``, so a viewer
    # only ever sees their own runs of a shared agent.
    await access.resolve_agent(user_id, agent_id)

    sessions = []
    for session in await storage.list_sessions(user_id, agent_id):
        try:
            await _require_session_scope(
                session,
                principal,
                session_scope_authorizer,
            )
        except HTTPException:
            continue
        sessions.append(session)
    views: list[SessionView] = []
    for session in sessions:
        team_detail = None
        if session.team_id:
            team_record = await storage.get_team(user_id, session.team_id)
            if team_record is not None:
                team_detail = await _build_team_detail(
                    storage,
                    access,
                    user_id,
                    team_record,
                )
        is_running = await message_bus.is_locked(
            MessageBusKeys.session_lock(session.id),
        )
        # Derived before the trim below, which drops the context it reads.
        session_status = (
            SessionStatus.RUNNING
            if is_running
            else SessionService.derive_parked_status(session.state.context)
        )
        views.append(
            SessionView(
                # ``context`` is the conversation the model sees,
                # ``summary`` its compressed form, and ``tool_context``
                # caches every file read — megabytes a session, none of
                # which a sidebar renders.
                session=session.model_copy(
                    update={
                        "state": session.state.model_copy(
                            update={
                                "context": [],
                                "summary": "",
                                "tool_context": ToolContext(),
                            },
                        ),
                    },
                ),
                is_running=is_running,
                status=session_status,
                team=team_detail,
            ),
        )
    return ListSessionsResponse(sessions=views, total=len(views))


@session_router.post(
    "/",
    response_model=CreateSessionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new session",
)
async def create_session(
    body: CreateSessionRequest,
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    workspace_manager: WorkspaceManagerBase = Depends(get_workspace_manager),
    access: ResourceAccessService = Depends(get_resource_access_service),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
) -> CreateSessionResponse:
    """Create (or resume) a session for a given agent and workspace.

    At most one session exists per ``(user_id, agent_id, workspace_id)``
    triple — a second call with the same triple updates the existing session
    rather than creating a duplicate.

    Args:
        body (`CreateSessionRequest`): Agent, workspace, and model config.
        user_id (`str`): Injected authenticated user ID.
        storage (`StorageBase`): Injected storage backend.
        workspace_manager (`WorkspaceManagerBase`): Injected workspace
            manager; consulted via
            :meth:`WorkspaceManagerBase.assign_workspace_id` to fill in
            ``workspace_id`` when the request body omits it.
        access (`ResourceAccessService`): Injected access service.

    Returns:
        `CreateSessionResponse`: The session identifier.

    Raises:
        `HTTPException`: 404 if the agent / credential / knowledge base
            is not visible to the caller.
    """
    # Agent must be visible to the caller (own or shared).
    await access.resolve_agent(user_id, body.agent_id)

    await _ensure_credential_exists(access, user_id, body.chat_model_config)
    await _ensure_credential_exists(
        access,
        user_id,
        body.fallback_chat_model_config,
    )
    await _ensure_credential_exists(access, user_id, body.tts_model_config)
    await _ensure_knowledge_bases_exist(
        access,
        user_id,
        body.knowledge_config,
    )

    if principal is not None and principal.customer_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="A customer session scope is required.",
        )

    session_id = _generate_id()

    # Resolve the workspace binding for this session. Explicit
    # ``body.workspace_id`` always wins (used by team invite / borrow
    # flows to force sharing); otherwise defer to the manager's
    # isolation policy — see ``WorkspaceManagerBase.assign_workspace_id``.
    resolved_workspace_id = body.workspace_id or (
        await workspace_manager.assign_workspace_id(
            user_id=user_id,
            agent_id=body.agent_id,
            session_id=session_id,
        )
    )

    session_record = await storage.upsert_session(
        user_id=user_id,
        agent_id=body.agent_id,
        session_id=session_id,
        tenant_id=principal.tenant_id if principal is not None else None,
        customer_id=principal.customer_id if principal is not None else None,
        config=SessionConfig(
            workspace_id=resolved_workspace_id,
            chat_model_config=body.chat_model_config,
            fallback_chat_model_config=body.fallback_chat_model_config,
            tts_model_config=body.tts_model_config,
            knowledge_config=body.knowledge_config,
            # A caller that named the session owns that name; anything
            # else starts on the creation timestamp and is the server's
            # to replace once the conversation says what it is about.
            naming=SessionNaming(auto=body.name is None),
            **({"name": body.name} if body.name is not None else {}),
        ),
    )
    return CreateSessionResponse(session_id=session_record.id)


@session_router.delete(
    "/{session_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a session",
)
async def delete_session(
    session_id: str,
    agent_id: str = Query(description="Agent the session belongs to."),
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    session_service: SessionService = Depends(get_session_service),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
    session_scope_authorizer: SessionScopeAuthorizer | None = Depends(
        get_session_scope_authorizer,
    ),
) -> None:
    """Permanently delete a session and all its associated state.

    Cancels any in-flight chat run for this session (and for every
    worker session if this one is a team leader) before dropping
    storage records and bus state. The cancel path is cross-process:
    whichever worker is actually running the session will receive the
    cancel broadcast and abort.

    Args:
        session_id (`str`): The session to delete.
        agent_id (`str`): The agent the session belongs to.
        user_id (`str`): Injected authenticated user ID.
        storage (`StorageBase`): Session storage used for the scope check
            before the cancellation cascade begins.
        session_service (`SessionService`): Injected session service.

    Raises:
        `HTTPException`: 404 if the session does not exist or does not belong
            to the authenticated user.
    """
    # Do not publish cancellation or start a deletion cascade until the
    # caller is authorized for this tenant/customer session.
    existing = await storage.get_session(user_id, agent_id, session_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )
    await _require_session_scope(
        existing,
        principal,
        session_scope_authorizer,
    )

    deleted = await session_service.delete_session(
        user_id,
        agent_id,
        session_id,
    )
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )


@session_router.post(
    "/{session_id}/interrupt",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Interrupt a running or HITL-parked chat run for a session",
    responses={
        404: {"description": "Session not found."},
    },
)
async def interrupt_session(
    session_id: str,
    agent_id: str = Query(description="Agent the session belongs to."),
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    chat_service: ChatService = Depends(get_chat_service),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
    session_scope_authorizer: SessionScopeAuthorizer | None = Depends(
        get_session_scope_authorizer,
    ),
) -> InterruptSessionResponse:
    """Request interruption of an in-progress reply for a session.

    Thin HTTP wrapper around :meth:`ChatService.interrupt`; see that
    method for the running vs not-running dispatch. Idempotent — an
    idle target session is a silent no-op at the agent layer.

    Args:
        session_id: The session whose reply should be interrupted.
        agent_id: The agent that owns the session.
        user_id: Injected authenticated user id.
        storage: Session storage used for the scope check before the
            interruption request is sent.
        chat_service: Injected chat service.

    Returns:
        202 with :class:`InterruptSessionResponse` echoing the
        session id.

    Raises:
        HTTPException: 404 if the session does not exist.
    """
    # Do not publish an interrupt or enqueue a resume until the caller is
    # authorized for this tenant/customer session.
    existing = await storage.get_session(user_id, agent_id, session_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )
    await _require_session_scope(
        existing,
        principal,
        session_scope_authorizer,
    )

    try:
        await chat_service.interrupt(user_id, session_id, agent_id)
    except LookupError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        ) from e
    return InterruptSessionResponse(session_id=session_id)


@session_router.patch(
    "/{session_id}",
    response_model=SessionRecord,
    summary="Update a session",
)
async def update_session(
    session_id: str,
    body: UpdateSessionRequest,
    agent_id: str = Query(description="Agent the session belongs to."),
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    access: ResourceAccessService = Depends(get_resource_access_service),
    message_bus: MessageBus = Depends(get_message_bus),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
    session_scope_authorizer: SessionScopeAuthorizer | None = Depends(
        get_session_scope_authorizer,
    ),
) -> SessionRecord:
    """Update the configuration of an existing session.

    Rejected while a chat run holds the session: the agent snapshots
    its configuration once at run start, so a mid-run change would be
    ignored for the current reply anyway — and writing it would race
    the run's own state persistence.

    Args:
        session_id (`str`): The session to update.
        body (`UpdateSessionRequest`): Fields to update.
        user_id (`str`): Injected authenticated user ID.
        storage (`StorageBase`): Injected storage backend.
        access (`ResourceAccessService`): Injected access service.
        message_bus (`MessageBus`): Injected message bus; used to
            detect an in-flight run.

    Returns:
        `SessionRecord`: The full session record after the update.

    Raises:
        `HTTPException`: 404 if the session does not exist, or if the
            referenced credential / KB is not visible to the caller;
            409 if a chat run is currently active on the session.
    """
    existing = await storage.get_session(user_id, agent_id, session_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )
    await _require_session_scope(
        existing,
        principal,
        session_scope_authorizer,
    )

    # Checked after the 404 so a missing session reports as missing, and
    # before the validation round trips below so we fail fast.
    if await message_bus.is_locked(MessageBusKeys.session_lock(session_id)):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Cannot modify session configuration while the session "
                "is running."
            ),
        )

    await _ensure_credential_exists(access, user_id, body.chat_model_config)
    await _ensure_credential_exists(
        access,
        user_id,
        body.fallback_chat_model_config,
    )
    await _ensure_credential_exists(access, user_id, body.tts_model_config)
    await _ensure_knowledge_bases_exist(
        access,
        user_id,
        body.knowledge_config,
    )

    # ``None`` leaves the stored state untouched (see
    # ``StorageBase.upsert_session``). ``permission_mode`` is the only
    # request field living inside ``state``; every other field is a
    # pure config write, and rewriting ``state`` for those would put
    # this handler's opening snapshot back over whatever the run has
    # persisted since.
    updated_state = None
    if body.permission_mode is not None:
        updated_ctx = existing.state.permission_context.model_copy(
            update={"mode": body.permission_mode},
        )

        updated_state = existing.state.model_copy(
            update={
                "permission_context": updated_ctx,
            },
        )

    # PATCH semantics: only fields explicitly present in the request body are
    # applied. ``exclude_unset=True`` lets clients distinguish "leave
    # unchanged" (omit) from "clear" (send ``null``) — required for clearing
    # ``fallback_chat_model_config``.
    config_updates = body.model_dump(
        exclude_unset=True,
        exclude={"permission_mode"},
    )

    # An explicit rename settles the name for good — auto-naming must
    # not overwrite what the user just typed.
    if "name" in config_updates:
        config_updates["naming"] = {
            **existing.config.naming.model_dump(),
            "auto": False,
        }

    return await storage.upsert_session(
        user_id=user_id,
        agent_id=agent_id,
        config=SessionConfig.model_validate(
            {**existing.config.model_dump(mode="json"), **config_updates},
        ),
        state=updated_state,
        session_id=session_id,
    )


# ----------------------------------------------------------------------
# Messages: fetch persisted messages for a session
# ----------------------------------------------------------------------


@session_router.get(
    "/{session_id}/messages",
    response_model=ListMessagesResponse,
    summary="List messages for a session",
)
async def list_messages(
    session_id: str,
    agent_id: str = Query(description="Agent the session belongs to."),
    before: str
    | None = Query(
        None,
        description=(
            "A message ID used as the pagination cursor. Omit to get "
            "the latest page. Provide a message ID from a previous "
            "response to load older messages."
        ),
    ),
    offset: int
    | None = Query(
        None,
        deprecated=True,
        description=(
            "**Deprecated.** Use ``before`` for cursor-based pagination. "
            "This parameter is always ignored."
        ),
    ),
    limit: int = Query(50, ge=1, le=200, description="Max messages."),
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    message_bus: MessageBus = Depends(get_message_bus),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
    session_scope_authorizer: SessionScopeAuthorizer | None = Depends(
        get_session_scope_authorizer,
    ),
) -> ListMessagesResponse:
    """Return persisted messages for a session with cursor-based
    pagination.

    Args:
        session_id: The session to query.
        agent_id: Agent the session belongs to.
        before: A message ID used as the pagination cursor. Omit for
            the latest page; provide a message ID from a previous
            response to load older messages.
        offset: **Deprecated.** Numeric offset, always ignored. Still
            accepted for backward compatibility.
        limit: Maximum number of messages to return.
        user_id: Injected authenticated user ID.
        storage: Injected storage backend.
        message_bus: Injected message bus.

    Returns:
        Messages, running status, and whether more pages exist.
    """
    existing = await storage.get_session(user_id, agent_id, session_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )
    await _require_session_scope(
        existing,
        principal,
        session_scope_authorizer,
    )

    # Forward deprecated offset via kwargs so storage can warn.
    extra: dict = {}
    if offset is not None:
        extra["offset"] = offset

    messages, has_more = await storage.list_messages(
        user_id,
        session_id,
        limit=limit,
        before=before,
        **extra,
    )
    return ListMessagesResponse(
        messages=messages,
        is_running=await message_bus.is_locked(
            MessageBusKeys.session_lock(session_id),
        ),
        has_more=has_more,
    )


# ----------------------------------------------------------------------
# Status probe: unified session status (cluster liveness + parking state)
# ----------------------------------------------------------------------


@session_router.get(
    "/{session_id}/status",
    response_model=SessionStatusResponse,
    summary="Probe the session's high-level status",
)
async def get_session_status(
    session_id: str,
    agent_id: str = Query(description="Agent the session belongs to."),
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    session_service: SessionService = Depends(get_session_service),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
    session_scope_authorizer: SessionScopeAuthorizer | None = Depends(
        get_session_scope_authorizer,
    ),
) -> SessionStatusResponse:
    """Return the unified :class:`SessionStatus` for a session.

    Ownership validation, cluster-liveness probing, and parked-state
    derivation are all delegated to
    :meth:`SessionService.get_session_status` — see that method for
    the precedence rules that collapse the two orthogonal signals
    (message-bus run lock + persisted context tail) into a single
    four-valued enum.

    Args:
        session_id (`str`):
            The session to probe.
        agent_id (`str`):
            The agent that owns the session (ownership validation).
        user_id (`str`):
            Injected authenticated user ID.
        storage (`StorageBase`):
            Session storage used for the scope check before any status
            signal is read.
        session_service (`SessionService`):
            Injected session service. Owns both storage and message
            bus dependencies so the composed answer is derived in a
            single layer.

    Returns:
        `SessionStatusResponse`:
            The probed session id and its unified status.

    Raises:
        `HTTPException`: 404 if the session does not exist or does not
            belong to the authenticated user.
    """
    # Scope must be checked before SessionService probes the distributed
    # run lock. Otherwise a caller with another user's session id could
    # learn whether that session is currently running.
    existing = await storage.get_session(user_id, agent_id, session_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )
    await _require_session_scope(
        existing,
        principal,
        session_scope_authorizer,
    )

    session_status = await session_service.get_session_status(
        user_id,
        agent_id,
        session_id,
    )
    if session_status is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )
    return SessionStatusResponse(
        session_id=session_id,
        status=session_status,
    )


# ----------------------------------------------------------------------
# Stream: live SSE connection for session events
# ----------------------------------------------------------------------

_HEARTBEAT_INTERVAL_SECS = 30
# Interval between SSE heartbeat comment frames (``:\\n\\n``).
_SESSION_SUBSCRIBE_TIMEOUT_SECS = 5.0
# Maximum time allowed for the message-bus subscription to become live.
STREAM_RESYNC_EVENT = "session_stream_resync"
#: Name of the ``CustomEvent`` sent when a subscriber's cursor is older than
#: the replay window.  It is a *snapshot*, not a delta: the client has provably
#: missed events that can no longer be delivered, so it is handed the durable
#: business state instead of being left to believe its replay was complete.


async def _build_stream_resync_payload(
    storage: StorageBase,
    user_id: str,
    agent_id: str,
    session_id: str,
    *,
    requested_cursor: str,
    resume_from: str | None,
) -> dict:
    """Describe the durable state a subscriber must resynchronise against.

    Only durable facts are reported.  The point is not to reconstruct the
    lost events — they are gone — but to give the client enough of the
    business state to rebuild its view, plus the cursor the event stream
    actually resumes from, so a trimmed cursor degrades into a resync
    rather than a silent gap.

    Args:
        storage (`StorageBase`):
            Application storage, read again here so the snapshot is
            current rather than as old as the request.
        user_id (`str`):
            The session owner.
        agent_id (`str`):
            The agent that owns the session.
        session_id (`str`):
            The session being streamed.
        requested_cursor (`str`):
            The cursor the client resumed from, which the log no longer
            holds.
        resume_from (`str | None`):
            The oldest entry that *is* still retained and will therefore
            be replayed next; ``None`` when nothing survived.

    Returns:
        `dict`:
            JSON-serializable snapshot value for the resync event.
    """
    record = await storage.get_session(user_id, agent_id, session_id)
    context = list(record.state.context or ()) if record is not None else []
    last = context[-1] if context else None
    pending: list[str] = []
    if last is not None:
        pending = [
            block.id
            for block in last.get_content_blocks("tool_call")
            if block.state in (ToolCallState.ASKING, ToolCallState.SUBMITTED)
        ]
    return {
        "reason": "cursor_expired",
        "session_id": session_id,
        "agent_id": agent_id,
        "requested_cursor": requested_cursor,
        "resume_from": resume_from,
        "context_length": len(context),
        "last_message_id": None if last is None else last.id,
        "last_message_role": None if last is None else last.role,
        "pending_confirmation_ids": pending,
    }


async def _worker_still_asking(
    storage: StorageBase,
    user_id: str,
    worker_agent_id: str,
    worker_session_id: str,
    reply_id: str,
) -> bool:
    """Return whether a worker session is still parked on the ASKING
    tool call identified by ``reply_id``.

    This is the reconcile-on-read check (design §3.5): the worker
    session's own ``state.context`` is the single source of truth for
    "does this confirmation still need answering". A leader-side
    pending projection whose worker has already resolved / cancelled
    the call is a ghost and must not be replayed.

    Mirrors the wakeup guard in
    :meth:`ChatService._run_impl` — a request is "still asking" when
    the tail ``AssistantMsg`` of the worker carries a tool call in
    ``ASKING`` or ``SUBMITTED`` state for the matching ``reply_id``.

    Args:
        storage (`StorageBase`):
            Application storage.
        user_id (`str`):
            The owner user id.
        worker_agent_id (`str`):
            The worker agent that owns the session.
        worker_session_id (`str`):
            The worker session to inspect.
        reply_id (`str`):
            The reply id the pending request belongs to.

    Returns:
        `bool`:
            ``True`` if the worker is still awaiting confirmation for
            ``reply_id``; ``False`` otherwise (resolved, cancelled, or
            the session/record is gone).
    """
    session = await storage.get_session(
        user_id,
        worker_agent_id,
        worker_session_id,
    )
    if session is None or not session.state.context:
        return False
    last_msg = session.state.context[-1]
    if last_msg.role != "assistant" or last_msg.id != reply_id:
        return False
    return any(
        tc.state in (ToolCallState.ASKING, ToolCallState.SUBMITTED)
        for tc in last_msg.get_content_blocks("tool_call")
    )


@session_router.get(
    "/{session_id}/stream",
    summary="Subscribe to a session's event stream (SSE)",
    response_description="Server-Sent Events stream of AgentEvent objects",
)
async def stream_session_events(
    session_id: str,
    agent_id: str = Query(description="Agent the session belongs to."),
    user_id: str = Depends(get_current_user_id),
    storage: StorageBase = Depends(get_storage),
    message_bus: MessageBus = Depends(get_message_bus),
    last_event_id: str | None = Header(
        default=None,
        alias="Last-Event-ID",
        description="Replay events strictly after this cursor.",
    ),
    principal: Annotated[
        Principal | None,
        Depends(get_current_principal_if_configured),
    ] = None,
    session_scope_authorizer: SessionScopeAuthorizer | None = Depends(
        get_session_scope_authorizer,
    ),
) -> StreamingResponse:
    """Subscribe to a session's live event stream.

    Returns a ``text/event-stream`` that first replays any buffered
    events from the session replay log, then streams live events as
    they are produced by :meth:`ChatService.run`. The connection stays open
    until the client disconnects — subsequent runs on the same session
    are delivered over the same connection.

    A heartbeat comment frame (``:\\n\\n``) is sent every 30 seconds to
    keep the connection alive through reverse proxies.

    ``Last-Event-ID`` is honoured as long as the named entry is still
    retained. When the replay window has already moved past it, the
    stream first emits a ``session_stream_resync`` ``CustomEvent``
    carrying the session's durable state and the cursor replay resumes
    from — a cursor that expired degrades into a resync instead of a
    silently incomplete replay.

    Args:
        session_id (`str`):
            The session to subscribe to.
        agent_id (`str`):
            The agent that owns the session (used for ownership
            validation).
        user_id (`str`):
            Injected authenticated user id.
        storage (`StorageBase`):
            Injected storage backend (ownership check only).
        message_bus (`MessageBus`):
            Injected message bus (replay + live subscription).
        last_event_id (`str | None`):
            Optional SSE cursor. Only events after this replay-log entry
            are delivered.

    Returns:
        `StreamingResponse`:
            SSE stream of AgentEvent frames + periodic heartbeats.
    """
    existing = await storage.get_session(user_id, agent_id, session_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session '{session_id}' not found.",
        )
    await _require_session_scope(
        existing,
        principal,
        session_scope_authorizer,
    )

    async def _sse_generator() -> AsyncGenerator[str, None]:
        event_key = MessageBusKeys.session_events(session_id)
        queue: asyncio.Queue[tuple[str | None, dict] | None] = asyncio.Queue()
        subscription_ready = asyncio.Event()
        feeder_error: Exception | None = None

        async def _feeder() -> None:
            """Read live events into a queue until the client disconnects."""
            nonlocal feeder_error
            try:
                async for evt in message_bus.subscribe(
                    event_key,
                    on_ready=subscription_ready.set,
                ):
                    entry_id = evt.get("_entry_id")
                    event = {k: v for k, v in evt.items() if k != "_entry_id"}
                    await queue.put((entry_id, event))
            except asyncio.CancelledError:
                pass
            except Exception as exc:  # pylint: disable=broad-except
                feeder_error = exc
            finally:
                subscription_ready.set()
                await queue.put(None)

        feeder_task = asyncio.create_task(
            _feeder(),
            name=f"sse-feeder:{session_id}",
        )
        replayed_ids: set[str] = set()

        try:
            # Subscribe first. Events published while replay is read are
            # queued and deduplicated by their replay-log entry id below.
            await asyncio.wait_for(
                subscription_ready.wait(),
                timeout=_SESSION_SUBSCRIBE_TIMEOUT_SECS,
            )
            if feeder_error is not None:
                raise feeder_error

            retained = await message_bus.log_read(
                event_key,
                since=last_event_id,
                max_count=MessageBusKeys.SESSION_REPLAY_MAX_LEN,
            )

            # A cursor older than the retained window cannot be honoured.
            # Replaying only what survived would look like a clean resume
            # while every trimmed event is lost, so the client is told and
            # given the durable state to resynchronise against instead.
            if last_event_id is not None and (
                await message_bus.log_cursor_expired(event_key, last_event_id)
            ):
                snapshot = await _build_stream_resync_payload(
                    storage,
                    user_id,
                    agent_id,
                    session_id,
                    requested_cursor=last_event_id,
                    resume_from=retained[0][0] if retained else None,
                )
                yield (
                    "data: "
                    + json.dumps(
                        CustomEvent(
                            name=STREAM_RESYNC_EVENT,
                            value=snapshot,
                        ).model_dump(mode="json"),
                        ensure_ascii=False,
                    )
                    + "\n\n"
                )

            for entry_id, event in retained:
                replayed_ids.add(entry_id)
                yield (
                    f"id: {entry_id}\n"
                    f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                )

            # 1b. Inject pending subagent HITL cards projected onto this
            #     session as a team leader (design §3.5). These live in a
            #     durable Redis hash, independently of session event replay.
            #
            #     Reconcile-on-read: the worker session's own context is the
            #     SSOT. Inject only when the worker is still ASKING; drop and
            #     delete ghosts (worker resolved/cancelled without clearing).
            projection = SessionProjection(message_bus)
            for payload in await projection.list(
                session_id,
                SubagentHitlProjector.KIND,
            ):
                if not await _worker_still_asking(
                    storage,
                    user_id,
                    payload["worker_agent_id"],
                    payload["worker_session_id"],
                    payload["reply_id"],
                ):
                    await projection.delete(
                        session_id,
                        SubagentHitlProjector.KIND,
                        SubagentHitlProjector.entry_id(
                            payload["worker_session_id"],
                            payload["reply_id"],
                        ),
                    )
                    continue
                custom = CustomEvent(
                    name=SubagentHitlProjector.EVT_REQUIRE,
                    value=payload,
                )
                data = json.dumps(
                    custom.model_dump(mode="json"),
                    ensure_ascii=False,
                )

                yield f"data: {data}\n\n"

            while True:
                try:
                    item = await asyncio.wait_for(
                        queue.get(),
                        timeout=_HEARTBEAT_INTERVAL_SECS,
                    )
                    if item is None:
                        break
                    entry_id, event = item
                    if entry_id is not None and entry_id in replayed_ids:
                        continue
                    if entry_id is not None:
                        replayed_ids.add(entry_id)
                    prefix = f"id: {entry_id}\n" if entry_id else ""
                    yield (
                        f"{prefix}"
                        f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                    )
                except asyncio.TimeoutError:
                    yield ":\n\n"
        finally:
            feeder_task.cancel()
            try:
                await feeder_task
            except asyncio.CancelledError:
                pass

    return StreamingResponse(
        _sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
