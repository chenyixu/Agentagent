# -*- coding: utf-8 -*-
"""Public browser authentication-mode discovery."""

from typing import Literal

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field


class AuthConfigResponse(BaseModel):
    """Non-sensitive information needed before browser sign-in."""

    mode: Literal["development", "bearer"] = Field(
        description="Whether the app accepts development identity or Bearer auth.",
    )
    token_required: bool = Field(
        description="Whether business routes require a verified Bearer token.",
    )
    development_identity_enabled: bool = Field(
        description="Whether the browser may use the explicit development identity.",
    )
    refresh_endpoint_configured: bool = Field(
        default=False,
        description=(
            "Whether a browser refresh endpoint is configured by the host "
            "application. Core AgentScope does not implement token refresh."
        ),
    )


auth_router = APIRouter(prefix="/auth", tags=["auth"])


@auth_router.get(
    "/config",
    response_model=AuthConfigResponse,
    summary="Discover the browser authentication mode",
)
async def get_auth_config(request: Request) -> AuthConfigResponse:
    """Return only the auth mode; never return tokens or provider secrets."""
    bearer_enabled = getattr(request.app.state, "identity_provider", None) is not None
    return AuthConfigResponse(
        mode="bearer" if bearer_enabled else "development",
        token_required=bearer_enabled,
        development_identity_enabled=not bearer_enabled,
    )
