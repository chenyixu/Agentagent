# -*- coding: utf-8 -*-
"""Shared type aliases for the agentscope app layer."""
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol

from pydantic import BaseModel, ConfigDict, Field

from ..agent import ContextConfig, ReActConfig
from ..event import AgentEvent
from ..middleware import MiddlewareBase
from ..permission import PermissionContext
from ..state import TaskContext
from ..tool import ToolBase
from ..workspace import WorkspaceBase

if TYPE_CHECKING:
    from fastapi import Request
    from ._service._session_projection import SessionProjection
    from .storage import AgentRecord, SessionRecord


class Principal(BaseModel):
    """Trusted identity context produced by the authentication boundary.

    The application must receive this object only after a gateway or an
    authentication provider has validated the caller's credentials.  It is
    deliberately immutable so downstream code cannot silently rewrite the
    tenant or customer scope while assembling tools.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    user_id: str = Field(min_length=1)
    tenant_id: str = Field(min_length=1)
    customer_id: str | None = Field(default=None, min_length=1)
    roles: frozenset[str] = frozenset()


class ToolScope(BaseModel):
    """The minimum server-side scope required by a business tool.

    ``ToolScope`` is derived from a verified identity and current
    authorization state.  It is not request input and is never exposed in
    the model-visible tool schema.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: str = Field(min_length=1)
    customer_id: str = Field(min_length=1)


class ToolExecutionContext(BaseModel):
    """Minimal backend context for tools that need audit correlation.

    ``ToolScope`` remains the data-access boundary. The requester and
    session fields describe who and where, not what business data the tool
    may access. This object is passed only to a server-side tool factory and
    is never model-visible.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    scope: ToolScope
    requester_user_id: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    idempotency_key: str | None = Field(default=None, min_length=1)


@dataclass(frozen=True)
class ToolExposurePolicy:
    """Server-side allow-list for the final model-visible toolkit.

    With no policy, AgentScope keeps its historical complete toolkit. An
    application can opt into a smaller surface and suppress whole delayed
    sources before they are constructed. The concrete tool allow-list is
    applied again after factories and middleware contribute their tools.
    """

    allowed_tool_names: frozenset[str] | None = None
    allowed_tool_groups: frozenset[str] | None = None
    allow_workspace_tools: bool = True
    allow_planning_tools: bool = True
    allow_background_tools: bool = True
    allow_schedule_tools: bool = True
    allow_team_tools: bool = True
    allow_middleware_tools: bool = True
    allow_channel_tools: bool = True
    allow_skills: bool = True
    allow_mcps: bool = True
    _framework_tool_names: frozenset[str] = field(
        default=frozenset(
            {
                "task_create",
                "task_list",
                "task_get",
                "task_update",
                "stop_background_task",
                "team_create",
                "agent_create",
                "team_say",
                "team_delete",
                "agent_invite",
            },
        ),
        repr=False,
    )

    def allows_tool(self, tool: ToolBase) -> bool:
        """Return whether a concrete tool may enter the basic group."""
        return (
            self.allowed_tool_names is None
            or tool.name in self.allowed_tool_names
        )

    def allows_group(self, group_name: str) -> bool:
        """Return whether a delayed tool group may be exposed."""
        return (
            self.allowed_tool_groups is None
            or group_name in self.allowed_tool_groups
        )

    def filter_tools(self, tools: list[ToolBase]) -> list[ToolBase]:
        """Apply the final concrete-tool allow-list."""
        return [tool for tool in tools if self.allows_tool(tool)]

    def filter_group(self, group: object) -> bool:
        """Apply the group allow-list without coupling this type to Toolkit."""
        return self.allows_group(getattr(group, "name", ""))


IdentityProvider = Callable[["Request"], Awaitable[Principal]]
# The provider owns JWT/OAuth or trusted-gateway verification.  AgentScope
# only consumes the resulting Principal and never parses raw credentials.

JWTClaimsVerifier = Callable[
    [str],
    Awaitable[dict[str, object]],
]
# Async verifier: a raw bearer token goes in, and claims are returned only
# after the verifier has completed cryptographic and standard claim checks.

ToolScopeResolver = Callable[[str, str, str], Awaitable[ToolScope]]
# Async resolver: ``(user_id, agent_id, session_id)`` → current, trusted
# scope.  ChatService calls it when the background run actually starts so a
# revoked authorization is not replaced by a scope captured at enqueue time.

SessionScopeAuthorizer = Callable[
    [Principal, "SessionRecord"],
    Awaitable[bool],
]
# Optional application hook for session grants such as staff assignments.
# The default framework check remains tenant/customer equality.

SessionRunAuthorizer = Callable[["SessionRecord"], Awaitable[bool]]
# Optional application hook that pauses automated runs while a human owns a
# session.  It is evaluated after the session is loaded and before tools are
# assembled.

SessionRunRevisionResolver = Callable[
    ["SessionRecord"],
    Awaitable[str | int | None],
]
# Optional application hook that returns the opaque revision of the current
# run-control record (for example a persisted handoff version). ChatService
# binds the value when a run starts and rechecks it before publishing each
# Agent event. The revision never enters the model context or tool schema.


class ChatQuotaService(Protocol):
    """Application quota contract for one admitted chat run.

    The returned reservation is an opaque application object. It must not
    enter the model prompt, tool schema, persisted user message, or SSE
    payload. Implementations own atomic capacity and accounting details.
    """

    async def reserve(
        self,
        *,
        tenant_id: str,
        run_id: str,
        input_chars: int,
        input_tokens: int | None = None,
        reserved_output_tokens: int | None = None,
    ) -> object:
        """Atomically admit a run and reserve output capacity."""

    async def settle(
        self,
        reservation: object,
        *,
        output_chars: int,
        tool_iterations: int,
        usage_known: bool,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
    ) -> object:
        """Settle usage and release active capacity exactly once."""

    async def cancel(self, reservation: object) -> None:
        """Release a reservation when the run is cancelled early."""


ChatEventObserver = Callable[
    [str, str, str, str, AgentEvent | None],
    Awaitable[None],
]
# Best-effort application observation hook. The phase is an internal label
# (for example ``request.started`` or ``agent.event``); the event itself is
# never enriched with trusted scope and is not sent to the model.

ScopedAgentToolFactory = Callable[[ToolScope], Awaitable[list[ToolBase]]]
# Strict business-tool factory: only the minimum tool scope is provided.

ScopedToolContextFactory = Callable[
    [ToolExecutionContext],
    Awaitable[list[ToolBase]],
]
# Dedicated factory for tools that additionally need the authenticated
# requester and source session for audit/correlation. It is separate from
# ``ScopedAgentToolFactory`` so order-only tools do not receive fields they
# do not need.


AgentMiddlewareFactory = (
    Callable[[str, str, str], Awaitable[list[MiddlewareBase]]]
    | Callable[
        [str, str, str, WorkspaceBase],
        Awaitable[list[MiddlewareBase]],
    ]
)
# Async factory: ``(user_id, agent_id, session_id, workspace)`` → awaitable
# of :class:`~agentscope.middleware.MiddlewareBase` instances. The legacy
# three-argument form stays supported — ``ChatService`` probes the signature
# and only passes ``workspace`` to factories that accept it.

AgentToolFactory = Callable[
    [str, str, str],
    Awaitable[list[ToolBase]],
]
#  Async factory signature: ``(user_id, agent_id, session_id)`` →
#  awaitable of :class:`~agentscope.tool.ToolBase` instances.


class EventProjector(Protocol):
    """Strategy that projects events from one session onto another.

    Each projector owns one cross-session UI feed (HITL, progress,
    errors, …). :class:`~agentscope.app._service.ChatService` calls
    every registered projector once per event produced by a run; a
    projector decides whether the event is relevant and, if so, mirrors
    it onto the owning session's target via the shared
    :class:`SessionProjection` primitive. Adding a feed means adding a
    projector — no new bus wrapper, dispatcher, or manager.

    Service dependencies a projector needs (e.g. storage, to resolve the
    team a worker belongs to) are its own concern, injected at
    construction. Only per-run request data is passed to
    :meth:`maybe_project`.
    """

    async def maybe_project(
        self,
        user_id: str,
        session_record: "SessionRecord",
        agent_record: "AgentRecord",
        event: AgentEvent,
        projection: "SessionProjection",
    ) -> None:
        """Project ``event`` if it is relevant to this feed.

        Implementations must be a no-op for irrelevant events and
        sessions. They should not raise for ordinary "not applicable"
        cases; ``ChatService`` guards the call with a catch-all so a
        projection failure never tears down the producing run, but
        projectors should not rely on that for control flow.

        Args:
            user_id (`str`):
                The owner of the running session.
            session_record (`SessionRecord`):
                The currently-running session's record.
            agent_record (`AgentRecord`):
                The currently-running agent's record.
            event (`AgentEvent`):
                The event just published to this session's channel.
            projection (`SessionProjection`):
                Shared primitive used to write the durable entry and the
                live notification.
        """


class SubAgentTemplate(BaseModel):
    """A reusable blueprint for sub-agent creation within a team.

    Developers register one or more templates at the ``create_app`` entry
    point. When the leader agent calls ``AgentCreate`` with a matching
    ``subagent_type``, the template's configuration is used instead of the
    built-in defaults.

    The :attr:`type` field serves as the routing key — it becomes an enum
    value of the ``subagent_type`` parameter exposed to the LLM.  This is
    distinct from the ``name`` parameter in ``AgentCreate``, which is the
    per-instance identifier the leader assigns to each worker (used for
    ``TeamSay(to=name)``).

    All fields are pure data (no callables), so the template is fully
    serializable for future config-driven startup.
    """

    type: str = Field(
        description=(
            "Template type identifier, e.g. ``'researcher'`` or "
            "``'coder'``. Used as the enum value for the "
            "``subagent_type`` parameter in ``AgentCreate``."
        ),
    )

    description: str = Field(
        description=(
            "Agent-readable description of this sub-agent type. "
            "Exposed to the LLM in the ``AgentCreate`` tool schema "
            "so it can choose the appropriate type."
        ),
    )

    system_prompt_template: str = Field(
        description=(
            "A Python format string for the worker's system prompt. "
            "Available placeholders: ``{team_name}``, "
            "``{team_description}``, ``{member_name}``, "
            "``{member_description}``, ``{leader_name}``."
        ),
    )

    context_config: ContextConfig = Field(
        default_factory=ContextConfig,
        description="Context configuration for the sub-agent.",
    )

    react_config: ReActConfig = Field(
        default_factory=ReActConfig,
        description="ReAct loop configuration for the sub-agent.",
    )

    permission_context: PermissionContext = Field(
        default_factory=PermissionContext,
        description=(
            "Permission context applied to the sub-agent at "
            "creation time. Controls what the worker is allowed "
            "to do (e.g. read-only vs. full access)."
        ),
    )

    override_leader_mode: bool = Field(
        default=False,
        description=(
            "Whether the template's :attr:`permission_context.mode` "
            "should override the leader session's mode for the worker. "
            "``True`` — the worker runs in the template's mode "
            "(typical for templates that pin a specific posture, e.g. "
            "a read-only research worker). ``False`` (default) — the "
            "worker inherits the leader's current mode."
        ),
    )

    extend_leader_permission_rules: bool = Field(
        default=True,
        description=(
            "Whether the leader session's allow/deny/ask permission "
            "rules should be merged on top of the template's. "
            "``True`` (default) — leader rules are appended after "
            "the template's rules for each tool, so the worker "
            "doesn't re-prompt for permissions the user has already "
            "confirmed; the template's rules take precedence on "
            "evaluation order. ``False`` — the template's rules are "
            "the worker's complete rule set."
        ),
    )

    extend_leader_working_directories: bool = Field(
        default=True,
        description=(
            "Whether the leader session's working directories should "
            "be merged into the template's. ``True`` (default) — "
            "leader directories are added for keys not already in the "
            "template (template wins on key collisions). ``False`` — "
            "the template's working directories are the worker's "
            "complete set."
        ),
    )

    tasks_context: TaskContext = Field(
        default_factory=TaskContext,
        description=(
            "Pre-defined task context for the sub-agent, allowing "
            "the template to seed an initial workflow."
        ),
    )
