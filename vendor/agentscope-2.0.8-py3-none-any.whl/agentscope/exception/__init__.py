# -*- coding: utf-8 -*-
"""The exception module in agentscope."""

from ._base import (
    AgentOrientedException,
    DeveloperOrientedException,
)
from ._model import StructuredOutputError
from ._tool import (
    FatalToolError,
    ToolInterruptedError,
    ToolNotFoundError,
    ToolJSONDecodeError,
    ToolGroupInactiveError,
)

__all__ = [
    "AgentOrientedException",
    "DeveloperOrientedException",
    "StructuredOutputError",
    "FatalToolError",
    "ToolInterruptedError",
    "ToolNotFoundError",
    "ToolJSONDecodeError",
    "ToolGroupInactiveError",
]
