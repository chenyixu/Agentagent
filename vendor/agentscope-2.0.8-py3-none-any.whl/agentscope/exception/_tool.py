# -*- coding: utf-8 -*-
"""The tool-related exceptions in agentscope."""

from ._base import AgentOrientedException, DeveloperOrientedException


class ToolNotFoundError(AgentOrientedException):
    """Exception raised when a tool was not found."""


class ToolInterruptedError(AgentOrientedException):
    """Exception raised when a tool calling was interrupted by the user."""


class ToolJSONDecodeError(AgentOrientedException):
    """Exception raised when tool arguments fail JSON decoding or repair."""


class ToolGroupInactiveError(AgentOrientedException):
    """Exception raised when a tool group is inactive."""


class FatalToolError(DeveloperOrientedException):
    """A tool failure that must terminate the current Agent reply.

    Unlike an :class:`AgentOrientedException`, this error is never converted
    into a model-visible tool result. Business tools should use it when
    continuing would be unsafe, for example after a scope/integrity failure
    or an unknown result from a side-effecting operation. The ChatService
    turns the propagated error into a sanitized ``ReplyEnd(ERROR)``.
    """
